import { Router } from 'express';
import { pool } from '../db.js';
import { ErroHttp, asyncH } from '../erros.js';
import { autenticar } from '../auth.js';
import { idParam, texto } from '../validar.js';

const router = Router();
router.use(autenticar);

// Reclamação (ligada ou não a uma corrida).
router.post(
  '/',
  asyncH(async (req, res) => {
    const u = req.utilizador;
    const descricao = texto(req.body?.descricao, 'descricao', { min: 5, max: 2000 });
    let corridaId = null;

    if (req.body?.corrida_id !== undefined && req.body.corrida_id !== null) {
      corridaId = idParam(req.body.corrida_id, 'corrida_id');
      const { rows } = await pool.query('SELECT cliente_id, motorista_id FROM corridas WHERE id = $1', [corridaId]);
      const c = rows[0];
      if (!c || (c.cliente_id !== u.id && c.motorista_id !== u.id)) throw new ErroHttp(404, 'Corrida não encontrada');
    }

    const { rows } = await pool.query(
      'INSERT INTO reclamacoes (corrida_id, autor_id, descricao) VALUES ($1, $2, $3) RETURNING id, estado, criada_em',
      [corridaId, u.id, descricao],
    );
    res.status(201).json({ reclamacao: rows[0] });
  }),
);

router.get(
  '/',
  asyncH(async (req, res) => {
    const { rows } = await pool.query(
      `SELECT id, corrida_id, descricao, estado, resolucao, criada_em, resolvida_em
         FROM reclamacoes WHERE autor_id = $1 ORDER BY id DESC LIMIT 50`,
      [req.utilizador.id],
    );
    res.json({ reclamacoes: rows });
  }),
);

export default router;
