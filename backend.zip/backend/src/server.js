import { config } from './config.js';
import { pool } from './db.js';
import { criarApp } from './app.js';
import { tarefasPeriodicas } from './manutencao.js';

const app = criarApp();
const servidor = app.listen(config.porta, () => {
  console.log(`API a correr na porta ${config.porta}`);
});

const timer = setInterval(() => {
  tarefasPeriodicas().catch((e) => console.error('[manutenção]', e.message));
}, 60_000);
timer.unref();

async function terminar(sinal) {
  console.log(`${sinal} recebido, a terminar...`);
  clearInterval(timer);
  servidor.close(async () => {
    await pool.end().catch(() => {});
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGINT', () => terminar('SIGINT'));
process.on('SIGTERM', () => terminar('SIGTERM'));
