import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { pool } from './db.js';
import { naoEncontrado, tratadorErros } from './erros.js';
import rotasAuth from './rotas/auth.js';
import rotasPublico from './rotas/publico.js';
import rotasCorridas from './rotas/corridas.js';
import rotasMotorista from './rotas/motorista.js';
import rotasSuporte from './rotas/suporte.js';
import rotasAdmin from './rotas/admin.js';

export function criarApp() {
  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', 1);

  app.use(helmet());
  app.use(cors({ origin: config.corsOrigens.length ? config.corsOrigens : false }));
  app.use(express.json({ limit: '100kb' }));

  app.get('/saude', async (req, res) => {
    try {
      await pool.query('SELECT 1');
      res.json({ ok: true });
    } catch {
      res.status(503).json({ ok: false });
    }
  });

  const limiteGeral = rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false, message: { erro: 'Demasiados pedidos. Tente novamente em instantes.' } });
  const limiteAuth = rateLimit({ windowMs: 15 * 60_000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { erro: 'Demasiadas tentativas. Tente novamente mais tarde.' } });

  app.use(limiteGeral);
  app.use('/api/auth', limiteAuth, rotasAuth);
  app.use('/api', rotasPublico);
  app.use('/api/corridas', rotasCorridas);
  app.use('/api/motorista', rotasMotorista);
  app.use('/api/reclamacoes', rotasSuporte);
  app.use('/api/admin', rotasAdmin);

  app.use(naoEncontrado);
  app.use(tratadorErros);
  return app;
}
