import { config } from './config.js';
import { ErroHttp } from './erros.js';
import { sqlDistKm } from './geo.js';
import { coordenadas, idParam, texto } from './validar.js';

const RAIO_ZONA_KM = 0.5;

// Se o ponto estiver a menos de 500 m de um ponto de referência, herda a zona dele.
async function localizarZona(db, lat, lng) {
  const { rows } = await db.query(
    `SELECT zona_id FROM (
       SELECT p.zona_id, ${sqlDistKm('p.latitude', 'p.longitude', '$1', '$2')} AS d
       FROM pontos_referencia p
       WHERE p.zona_id IS NOT NULL
     ) t
     WHERE d <= $3
     ORDER BY d
     LIMIT 1`,
    [lat, lng, RAIO_ZONA_KM],
  );
  return rows[0]?.zona_id ?? null;
}

// Aceita { ponto_id } ou { lat, lng }, com descrição opcional.
export async function resolverLocal(db, entrada, nome) {
  if (!entrada || typeof entrada !== 'object') throw new ErroHttp(400, `O campo "${nome}" é obrigatório`);
  const descricaoEntrada = texto(entrada.descricao, `descrição de ${nome}`, { max: 200, opcional: true });

  if (entrada.ponto_id !== undefined && entrada.ponto_id !== null) {
    const id = idParam(entrada.ponto_id, `ponto_id de ${nome}`);
    const { rows } = await db.query(
      'SELECT id, nome, latitude, longitude, zona_id FROM pontos_referencia WHERE id = $1',
      [id],
    );
    if (!rows.length) throw new ErroHttp(404, `Ponto de referência de ${nome} não encontrado`);
    const p = rows[0];
    return { lat: p.latitude, lng: p.longitude, descricao: descricaoEntrada ?? p.nome, ponto_id: p.id, zona_id: p.zona_id };
  }

  const { lat, lng } = coordenadas(entrada.lat, entrada.lng, nome);
  return { lat, lng, descricao: descricaoEntrada, ponto_id: null, zona_id: await localizarZona(db, lat, lng) };
}

// Preço fixo entre zonas (se existir) ou taxa base + preço por km.
export async function calcularPreco(db, { tipo, km, zonaOrigem, zonaDestino }) {
  const { rows } = await db.query('SELECT * FROM tarifas WHERE tipo_veiculo = $1 AND ativo ORDER BY id', [tipo]);

  if (zonaOrigem && zonaDestino) {
    const fixa = rows.find(
      (t) => t.zona_origem_id === zonaOrigem && t.zona_destino_id === zonaDestino && t.preco_fixo !== null,
    );
    if (fixa) return { preco: fixa.preco_fixo, tarifa: 'fixa' };
  }

  const geral = rows.find((t) => t.zona_origem_id === null && t.zona_destino_id === null && t.preco_por_km !== null);
  if (!geral) throw new ErroHttp(422, 'Ainda não há tarifa configurada para este tipo de veículo');

  const bruto = geral.taxa_base + geral.preco_por_km * km;
  const arredondado = Math.ceil(bruto / config.arredondarPara - 1e-9) * config.arredondarPara;
  return { preco: Math.max(arredondado, config.arredondarPara), tarifa: 'por_km' };
}
