import pg from 'pg';
import { config } from './config.js';

const { Pool, types } = pg;

// Tipos devolvidos como números/strings simples em vez de strings do driver
types.setTypeParser(20, (v) => parseInt(v, 10)); // BIGINT / COUNT(*)
types.setTypeParser(1700, (v) => parseFloat(v)); // NUMERIC (valores em MT)
types.setTypeParser(1082, (v) => v); // DATE -> "AAAA-MM-DD"
types.setTypeParser(1114, (v) => new Date(`${v.replace(' ', 'T')}Z`)); // TIMESTAMP guardado em UTC

export const pool = new Pool({ connectionString: config.databaseUrl, max: 10 });

// Todas as sessões trabalham em UTC; a conversão para hora local é feita nas consultas.
pool.on('connect', (cliente) => {
  cliente.query("SET TIME ZONE 'UTC'").catch((e) => console.error('[db] SET TIME ZONE falhou', e.message));
});
pool.on('error', (e) => console.error('[db] erro numa ligação inativa:', e.message));

export const query = (texto, params) => pool.query(texto, params);

export async function tx(fn) {
  const cliente = await pool.connect();
  try {
    await cliente.query('BEGIN');
    const resultado = await fn(cliente);
    await cliente.query('COMMIT');
    return resultado;
  } catch (e) {
    try {
      await cliente.query('ROLLBACK');
    } catch {
      /* ligação já perdida */
    }
    throw e;
  } finally {
    cliente.release();
  }
}
