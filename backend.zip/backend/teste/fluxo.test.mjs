// Teste de ponta a ponta: percorre uma corrida completa pela API, contra uma base de dados REAL.
//
// Como correr (numa base de testes, NUNCA na base de produção):
//   1) createdb transportes_teste
//   2) no .env:  DATABASE_URL=postgres://utilizador:senha@localhost:5432/transportes_teste
//   3) npm run migrar
//   4) npm test
import test from 'node:test';
import assert from 'node:assert/strict';

const { config } = await import('../src/config.js');
if (!/teste|test/i.test(config.databaseUrl)) {
  throw new Error('Por segurança, este teste só corre se o nome da base de dados contiver "teste" ou "test".');
}
const { criarApp } = await import('../src/app.js');
const { pool } = await import('../src/db.js');

// Captura o código SMS que o modo "consola" escreve no terminal.
const codigos = new Map();
const logOriginal = console.log;
console.log = (...args) => {
  const m = String(args[0]).match(/\[SMS para \+(\d+)\].*?(\d{6})/);
  if (m) codigos.set(m[1], m[2]);
  else logOriginal(...args);
};

const servidor = criarApp().listen(0);
await new Promise((r) => servidor.once('listening', r));
const base = `http://127.0.0.1:${servidor.address().port}`;

async function api(metodo, caminho, token, corpo) {
  const r = await fetch(`${base}${caminho}`, {
    method: metodo,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: corpo === undefined ? undefined : JSON.stringify(corpo),
  });
  const texto = await r.text();
  let json = null;
  try { json = JSON.parse(texto); } catch { /* resposta não JSON (ex.: CSV) */ }
  return { status: r.status, json, texto };
}

const sufixo = () => String(Math.floor(Math.random() * 1e7)).padStart(7, '0');

async function entrar(telefoneLocal, extra = {}) {
  const pedido = await api('POST', '/api/auth/pedir-codigo', null, { telefone: telefoneLocal });
  assert.equal(pedido.status, 200, pedido.texto);
  const telefone = `258${telefoneLocal}`;
  const codigo = codigos.get(telefone);
  assert.ok(codigo, 'o código SMS devia ter sido emitido');
  const r = await api('POST', '/api/auth/verificar-codigo', null, { telefone: telefoneLocal, codigo, ...extra });
  assert.ok([200, 201].includes(r.status), r.texto);
  return { token: r.json.token, id: r.json.utilizador.id };
}

const ORIGEM = { lat: -14.8035, lng: 36.538 };
const DESTINO = { lat: -14.82, lng: 36.538 };

test('fluxo completo: pedido, aceitação, viagem, comissão e relatório', async (t) => {
  t.after(async () => {
    console.log = logOriginal;
    await new Promise((r) => servidor.close(r));
    await pool.end();
  });

  // --- Utilizadores ---
  const telAdmin = `84${sufixo()}`;
  await pool.query(
    `INSERT INTO utilizadores (nome, telefone, tipo) VALUES ('Admin Teste', $1, 'admin')`,
    [`258${telAdmin}`],
  );
  const admin = await entrar(telAdmin);
  const cliente = await entrar(`85${sufixo()}`, { nome: 'Cliente Teste' });
  const motorista = await entrar(`86${sufixo()}`, { nome: 'Motorista Teste', tipo: 'motorista' });

  // Primeiro acesso sem nome é recusado e o código continua válido
  const tel = `87${sufixo()}`;
  await api('POST', '/api/auth/pedir-codigo', null, { telefone: tel });
  const semNome = await api('POST', '/api/auth/verificar-codigo', null, { telefone: tel, codigo: codigos.get(`258${tel}`) });
  assert.equal(semNome.status, 400);
  const comNome = await api('POST', '/api/auth/verificar-codigo', null, { telefone: tel, codigo: codigos.get(`258${tel}`), nome: 'Outro' });
  assert.equal(comNome.status, 201);

  // Sem sessão não há acesso
  assert.equal((await api('GET', '/api/auth/eu')).status, 401);
  assert.equal((await api('GET', '/api/admin/dashboard', cliente.token)).status, 403);

  // --- Tarifa e perfil do motorista ---
  const tarifa = await api('POST', '/api/admin/tarifas', admin.token, { tipo_veiculo: 'taxi', taxa_base: 50, preco_por_km: 25 });
  assert.equal(tarifa.status, 201, tarifa.texto);

  const perfil = await api('POST', '/api/motorista/perfil', motorista.token, {
    numero_carta: 'CARTA-TESTE',
    validade_carta: '2035-12-31',
    veiculo: { tipo: 'taxi', matricula: `T${sufixo()}`, validade_seguro: '2035-01-01', validade_licenca: '2035-01-01' },
  });
  assert.equal(perfil.status, 201, perfil.texto);

  // Ainda por aprovar: não pode ficar online
  const cedo = await api('POST', '/api/motorista/estado', motorista.token, { online: true, ...ORIGEM });
  assert.equal(cedo.status, 403);

  const aprov = await api('POST', `/api/admin/motoristas/${motorista.id}/verificacao`, admin.token, { estado: 'aprovado' });
  assert.equal(aprov.status, 200, aprov.texto);
  const online = await api('POST', '/api/motorista/estado', motorista.token, { online: true, ...ORIGEM });
  assert.equal(online.status, 200, online.texto);

  // --- Pedido ---
  const est = await api('POST', '/api/corridas/estimativa', cliente.token, { tipo_veiculo: 'taxi', origem: ORIGEM, destino: DESTINO });
  assert.equal(est.status, 200, est.texto);
  assert.ok(est.json.preco_estimado >= 50);

  const mpesa = await api('POST', '/api/corridas', cliente.token, { tipo_veiculo: 'taxi', origem: ORIGEM, destino: DESTINO, metodo_pagamento: 'mpesa' });
  assert.equal(mpesa.status, 422, 'M-Pesa ainda não está ativo');

  const pedido = await api('POST', '/api/corridas', cliente.token, { tipo_veiculo: 'taxi', origem: ORIGEM, destino: DESTINO });
  assert.equal(pedido.status, 201, pedido.texto);
  const corrida = pedido.json.corrida;
  assert.equal(corrida.estado, 'pedida');

  const duplo = await api('POST', '/api/corridas', cliente.token, { tipo_veiculo: 'taxi', origem: ORIGEM, destino: DESTINO });
  assert.equal(duplo.status, 409, 'só uma corrida ativa por cliente');

  // --- Motorista ---
  const lista = await api('GET', '/api/motorista/pedidos', motorista.token);
  assert.equal(lista.status, 200, lista.texto);
  assert.ok(lista.json.pedidos.some((p) => p.id === corrida.id), 'o pedido devia aparecer na lista');

  const aceite = await api('POST', `/api/corridas/${corrida.id}/aceitar`, motorista.token);
  assert.equal(aceite.status, 200, aceite.texto);
  assert.equal(aceite.json.corrida.estado, 'aceite');
  assert.equal((await api('POST', `/api/corridas/${corrida.id}/aceitar`, motorista.token)).status, 409);

  assert.equal((await api('POST', `/api/corridas/${corrida.id}/concluir`, motorista.token)).status, 409, 'não se conclui antes de iniciar');
  assert.equal((await api('POST', `/api/corridas/${corrida.id}/a-caminho`, motorista.token)).status, 200);
  assert.equal((await api('POST', `/api/corridas/${corrida.id}/iniciar`, motorista.token)).status, 200);

  const atual = await api('GET', '/api/corridas/atual', cliente.token);
  assert.equal(atual.json.corrida.estado, 'em_curso');

  const acima = await api('POST', `/api/corridas/${corrida.id}/concluir`, motorista.token, { preco_final: corrida.preco_estimado * 5 });
  assert.equal(acima.status, 422, 'o preço final não pode disparar');

  const fim = await api('POST', `/api/corridas/${corrida.id}/concluir`, motorista.token);
  assert.equal(fim.status, 200, fim.texto);
  assert.equal(fim.json.corrida.estado, 'concluida');
  const esperada = Math.round(fim.json.corrida.preco_final * config.comissaoPercentagem) / 100;
  assert.ok(Math.abs(fim.json.comissao.valor - esperada) < 0.01, `comissão ${fim.json.comissao.valor} ≠ ${esperada}`);
  assert.equal(fim.json.saldo_comissoes, fim.json.comissao.valor);

  // --- Avaliação e ganhos ---
  assert.equal((await api('POST', `/api/corridas/${corrida.id}/avaliar`, cliente.token, { nota: 5, comentario: 'Boa viagem' })).status, 201);
  assert.equal((await api('POST', `/api/corridas/${corrida.id}/avaliar`, cliente.token, { nota: 4 })).status, 409);
  const ganhos = await api('GET', '/api/motorista/ganhos?periodo=dia', motorista.token);
  assert.equal(ganhos.status, 200, ganhos.texto);
  assert.equal(ganhos.json.corridas, 1);
  const eu = await api('GET', '/api/motorista/perfil', motorista.token);
  assert.equal(eu.json.perfil.avaliacao_media, 5);

  // --- Administração: comissões e relatório ---
  const devedores = await api('GET', '/api/admin/comissoes', admin.token);
  assert.ok(devedores.json.devedores.some((d) => d.motorista_id === motorista.id));
  const pag = await api('POST', '/api/admin/comissoes/pagamento', admin.token, { motorista_id: motorista.id, valor: fim.json.comissao.valor, referencia: 'teste' });
  assert.equal(pag.status, 200, pag.texto);
  assert.equal(pag.json.saldo_comissoes, 0);

  const ontem = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
  const amanha = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const rel = await api('GET', `/api/admin/relatorio?de=${ontem}&ate=${amanha}`, admin.token);
  assert.equal(rel.status, 200, rel.texto);
  assert.ok(rel.json.total.corridas >= 1);
  const relCsv = await api('GET', `/api/admin/relatorio?de=${ontem}&ate=${amanha}&formato=csv`, admin.token);
  assert.equal(relCsv.status, 200);
  assert.match(relCsv.texto, /Movimento \(MT\)/);

  // --- Partilha da viagem (pública) ---
  const partilha = await api('GET', `/api/partilha/${corrida.codigo_partilha}`);
  assert.equal(partilha.status, 200, partilha.texto);
  assert.equal((await api('GET', '/api/partilha/0000000000000000')).status, 404);

  // --- Cancelamento ---
  const nova = await api('POST', '/api/corridas', cliente.token, { tipo_veiculo: 'taxi', origem: ORIGEM, destino: DESTINO });
  assert.equal(nova.status, 201, nova.texto);
  const canc = await api('POST', `/api/corridas/${nova.json.corrida.id}/cancelar`, cliente.token, {});
  assert.equal(canc.status, 200, canc.texto);
  assert.equal(canc.json.corrida.estado, 'cancelada');
});
