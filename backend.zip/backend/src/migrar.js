import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from './db.js';

const pasta = join(dirname(fileURLToPath(import.meta.url)), '..', 'migrations');
const ficheiros = readdirSync(pasta).filter((f) => f.endsWith('.sql')).sort();

const cliente = await pool.connect();
try {
  await cliente.query('CREATE TABLE IF NOT EXISTS migracoes (nome TEXT PRIMARY KEY, aplicada_em TIMESTAMP NOT NULL DEFAULT NOW())');
  const { rows } = await cliente.query('SELECT nome FROM migracoes');
  const feitas = new Set(rows.map((r) => r.nome));

  for (const f of ficheiros) {
    if (feitas.has(f)) continue;
    console.log(`A aplicar ${f}...`);
    try {
      await cliente.query('BEGIN');
      await cliente.query(readFileSync(join(pasta, f), 'utf8'));
      await cliente.query('INSERT INTO migracoes (nome) VALUES ($1)', [f]);
      await cliente.query('COMMIT');
    } catch (e) {
      await cliente.query('ROLLBACK');
      throw new Error(`Falha em ${f}: ${e.message}`);
    }
  }
  console.log('Base de dados atualizada.');
} finally {
  cliente.release();
  await pool.end();
}
