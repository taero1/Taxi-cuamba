import { config } from './config.js';

export const arredondar2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

// Data de hoje (AAAA-MM-DD) no fuso horário configurado.
export function hojeLocal() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: config.fuso,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

// Início do dia/semana/mês (no fuso local) expresso em UTC, para comparar com colunas TIMESTAMP guardadas em UTC.
// `unidade` e `fuso` são referências a parâmetros SQL (ex.: '$1', '$2'), nunca texto vindo do utilizador.
export function sqlInicioPeriodo(unidade, fuso) {
  return `((date_trunc(${unidade}::text, (NOW() AT TIME ZONE ${fuso}::text)) AT TIME ZONE ${fuso}::text) AT TIME ZONE 'UTC')`;
}

// Constrói "coluna = $n, ..." a partir de um objeto, ignorando campos undefined.
// As chaves vêm sempre do código (nunca do pedido), por isso são seguras.
export function montarSet(campos, primeiroIndice = 1) {
  const chaves = Object.keys(campos).filter((k) => campos[k] !== undefined);
  return {
    chaves,
    set: chaves.map((k, i) => `${k} = $${primeiroIndice + i}`).join(', '),
    valores: chaves.map((k) => campos[k]),
  };
}

// CSV pensado para Excel em português: separador ";", decimais com vírgula e BOM UTF-8.
export function csv(colunas, linhas) {
  const esc = (v) => {
    if (v === null || v === undefined) return '';
    let s = typeof v === 'number' ? String(v).replace('.', ',') : String(v);
    if (typeof v === 'string' && /^[=+\-@\t\r]/.test(s)) s = `'${s}`; // evita injeção de fórmulas
    return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const cabecalho = colunas.map((c) => c.titulo).join(';');
  const corpo = linhas.map((l) => colunas.map((c) => esc(l[c.chave])).join(';'));
  return `﻿${[cabecalho, ...corpo].join('\r\n')}\r\n`;
}
