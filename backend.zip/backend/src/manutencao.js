import { config } from './config.js';
import { pool } from './db.js';

let ciclos = 0;

// Tarefas de limpeza executadas a cada minuto pelo servidor.
export async function tarefasPeriodicas() {
  ciclos += 1;

  // 1) Pedidos que ninguém aceitou são cancelados, para o cliente poder pedir de novo.
  const expirados = await pool.query(
    `UPDATE corridas
        SET estado = 'cancelada', cancelada_em = NOW(), motivo_cancelamento = 'Sem motorista disponível'
      WHERE estado = 'pedida' AND pedida_em < NOW() - make_interval(mins => $1::int)
      RETURNING id`,
    [config.tempoMaxPedidoMin],
  );
  if (expirados.rowCount) {
    await pool.query(
      `UPDATE pagamentos SET estado = 'falhado', referencia_transacao = 'corrida_cancelada'
        WHERE corrida_id = ANY($1::bigint[])`,
      [expirados.rows.map((r) => r.id)],
    );
  }

  // 2) Motoristas que deixaram de enviar localização (sem corrida ativa) passam a offline.
  await pool.query(
    `UPDATE motoristas m SET online = FALSE
      WHERE m.online
        AND NOT EXISTS (
          SELECT 1 FROM corridas c
           WHERE c.motorista_id = m.utilizador_id AND c.estado IN ('aceite', 'a_caminho', 'em_curso'))
        AND COALESCE(
              (SELECT MAX(l.registado_em) FROM localizacoes_motoristas l WHERE l.motorista_id = m.utilizador_id),
              TIMESTAMP '1970-01-01') < NOW() - make_interval(mins => $1::int)`,
    [config.offlineAposMin],
  );

  // 3) Limpeza periódica de dados antigos (cerca de uma vez por hora).
  if (ciclos % 60 === 1) {
    await pool.query("DELETE FROM localizacoes_motoristas WHERE registado_em < NOW() - INTERVAL '2 days'");
    await pool.query("DELETE FROM otp_codigos WHERE criado_em < NOW() - INTERVAL '1 day'");
  }
}
