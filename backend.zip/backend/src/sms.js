import { config } from './config.js';

// Envia um SMS. Em modo "consola" apenas escreve no terminal (testes).
// Para produção, ligue aqui o fornecedor de SMS escolhido (ex.: um agregador com cobertura em Moçambique)
// e use um SMS_MODO com o nome dele no .env.
export async function enviarSms(telefone, mensagem) {
  if (config.smsModo === 'consola') {
    console.log(`[SMS para +${telefone}] ${mensagem}`);
    return;
  }
  throw new Error(`SMS_MODO="${config.smsModo}" não tem fornecedor ligado. Implemente-o em src/sms.js`);
}
