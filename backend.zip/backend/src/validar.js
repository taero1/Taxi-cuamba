import { ErroHttp } from './erros.js';

const vazio = (v) => v === undefined || v === null || v === '';

export function texto(v, nome, { min = 1, max = 200, opcional = false } = {}) {
  if (vazio(v)) {
    if (opcional) return null;
    throw new ErroHttp(400, `O campo "${nome}" é obrigatório`);
  }
  if (typeof v !== 'string') throw new ErroHttp(400, `O campo "${nome}" deve ser texto`);
  const t = v.trim();
  if (t.length < min || t.length > max) {
    throw new ErroHttp(400, `O campo "${nome}" deve ter entre ${min} e ${max} caracteres`);
  }
  return t;
}

export function numero(v, nome, { min = -Infinity, max = Infinity, opcional = false } = {}) {
  if (vazio(v)) {
    if (opcional) return null;
    throw new ErroHttp(400, `O campo "${nome}" é obrigatório`);
  }
  const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN;
  if (!Number.isFinite(n) || n < min || n > max) {
    throw new ErroHttp(400, `O campo "${nome}" é inválido`);
  }
  return n;
}

export function inteiro(v, nome, opcoes = {}) {
  const n = numero(v, nome, opcoes);
  if (n !== null && !Number.isInteger(n)) throw new ErroHttp(400, `O campo "${nome}" deve ser um número inteiro`);
  return n;
}

export function idParam(v, nome = 'id') {
  if (!/^\d{1,15}$/.test(String(v ?? ''))) throw new ErroHttp(400, `"${nome}" inválido`);
  const n = Number(v);
  if (n < 1) throw new ErroHttp(400, `"${nome}" inválido`);
  return n;
}

export function enumerado(v, nome, lista) {
  if (!lista.includes(v)) throw new ErroHttp(400, `O campo "${nome}" deve ser um de: ${lista.join(', ')}`);
  return v;
}

export function booleano(v, nome) {
  if (typeof v !== 'boolean') throw new ErroHttp(400, `O campo "${nome}" deve ser verdadeiro ou falso`);
  return v;
}

export function dataISO(v, nome, { opcional = false } = {}) {
  if (vazio(v)) {
    if (opcional) return null;
    throw new ErroHttp(400, `O campo "${nome}" é obrigatório (formato AAAA-MM-DD)`);
  }
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) {
    throw new ErroHttp(400, `O campo "${nome}" deve ter o formato AAAA-MM-DD`);
  }
  const [a, m, d] = v.split('-').map(Number);
  const dt = new Date(Date.UTC(a, m - 1, d));
  if (dt.getUTCFullYear() !== a || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) {
    throw new ErroHttp(400, `O campo "${nome}" não é uma data válida`);
  }
  return v;
}

export function coordenadas(lat, lng, nome = '') {
  const sufixo = nome ? ` de ${nome}` : '';
  return {
    lat: numero(lat, `latitude${sufixo}`, { min: -90, max: 90 }),
    lng: numero(lng, `longitude${sufixo}`, { min: -180, max: 180 }),
  };
}

export function urlHttps(v, nome, { opcional = true } = {}) {
  const t = texto(v, nome, { max: 255, opcional });
  if (t !== null && !/^https:\/\/\S+$/.test(t)) throw new ErroHttp(400, `O campo "${nome}" deve ser um endereço https`);
  return t;
}

// Números móveis de Moçambique: 82-87 + 7 dígitos, com ou sem +258.
export function normalizarTelefone(v) {
  const d = String(v ?? '').replace(/[\s\-().+]/g, '');
  if (/^8[2-7]\d{7}$/.test(d)) return `258${d}`;
  if (/^2588[2-7]\d{7}$/.test(d)) return d;
  throw new ErroHttp(400, 'Número de telefone inválido. Use o formato 84 123 4567 ou +258 84 123 4567');
}
