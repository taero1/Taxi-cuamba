import { Router } from 'express';
import { pool } from '../db.js';
import { ErroHttp, asyncH } from '../erros.js';
import { idParam, texto } from '../validar.js';

const router = Router();

router.get(
  '/zonas',
  asyncH(async (req, res) => {
    const { rows } = await pool.query('SELECT id, nome, cidade FROM zonas ORDER BY cidade, nome');
    res.json({ zonas: rows });
  }),
);

// Pesquisa de pontos de referência (mercado, escola, hospital...) por nome.
router.get(
  '/pontos',
  asyncH(async (req, res) => {
    const q = texto(req.query.q, 'q', { max: 60, opcional: true });
    const zona = req.query.zona_id ? idParam(req.query.zona_id, 'zona_id') : null;
    const { rows } = await pool.query(
      `SELECT id, nome, categoria, latitude, longitude, zona_id
         FROM pontos_referencia
        WHERE ($1::text IS NULL OR LOWER(nome) LIKE '%' || LOWER($1::text) || '%')
          AND ($2::bigint IS NULL OR zona_id = $2::bigint)
        ORDER BY nome
        LIMIT 50`,
      [q, zona],
    );
    res.json({ pontos: rows });
  }),
);

// Ligação de partilha da viagem: quem a recebe vê o estado e a localização do motorista, sem iniciar sessão.
router.get(
  '/partilha/:codigo',
  asyncH(async (req, res) => {
    const codigo = String(req.params.codigo);
    if (!/^[0-9a-f]{16}$/.test(codigo)) throw new ErroHttp(404, 'Viagem não encontrada');

    const { rows } = await pool.query(
      `SELECT c.estado, c.origem_descricao, c.destino_descricao, c.concluida_em,
              mu.nome AS motorista_nome, v.matricula, v.marca_modelo, v.cor,
              loc.lat AS motorista_lat, loc.lng AS motorista_lng, loc.em AS atualizado_em
         FROM corridas c
         LEFT JOIN utilizadores mu ON mu.id = c.motorista_id
         LEFT JOIN veiculos v ON v.id = c.veiculo_id
         LEFT JOIN LATERAL (
           SELECT l.latitude AS lat, l.longitude AS lng, l.registado_em AS em
             FROM localizacoes_motoristas l
            WHERE l.motorista_id = c.motorista_id
            ORDER BY l.registado_em DESC LIMIT 1
         ) loc ON TRUE
        WHERE c.codigo_partilha = $1
          AND (c.estado IN ('pedida', 'aceite', 'a_caminho', 'em_curso')
               OR c.concluida_em > NOW() - INTERVAL '2 hours')`,
      [codigo],
    );
    if (!rows.length) throw new ErroHttp(404, 'Viagem não encontrada ou já terminada');

    const r = rows[0];
    const ativa = ['aceite', 'a_caminho', 'em_curso'].includes(r.estado);
    res.json({
      viagem: {
        estado: r.estado,
        origem: r.origem_descricao,
        destino: r.destino_descricao,
        motorista: r.motorista_nome,
        veiculo: r.matricula ? { matricula: r.matricula, modelo: r.marca_modelo, cor: r.cor } : null,
        localizacao: ativa && r.motorista_lat !== null ? { lat: r.motorista_lat, lng: r.motorista_lng, atualizado_em: r.atualizado_em } : null,
      },
    });
  }),
);

export default router;
