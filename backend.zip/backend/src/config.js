import 'dotenv/config';

function numero(nome, padrao, { min = -Infinity, max = Infinity } = {}) {
  const bruto = process.env[nome];
  if (bruto === undefined || bruto === '') return padrao;
  const n = Number(bruto);
  if (!Number.isFinite(n) || n < min || n > max) {
    throw new Error(`Variável ${nome} inválida: "${bruto}"`);
  }
  return n;
}

const producao = process.env.NODE_ENV === 'production';
const jwtSegredo = process.env.JWT_SEGREDO ?? '';

if (jwtSegredo.length < 16) {
  throw new Error('JWT_SEGREDO em falta ou demasiado curto (mínimo 16 caracteres). Veja .env.example');
}
if (producao && jwtSegredo.startsWith('troque-isto')) {
  throw new Error('Troque o JWT_SEGREDO de exemplo por um segredo próprio antes de usar em produção.');
}
if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL em falta. Veja .env.example');
}

export const config = {
  producao,
  porta: numero('PORT', 3000, { min: 1, max: 65535 }),
  databaseUrl: process.env.DATABASE_URL,
  jwtSegredo,
  jwtValidade: process.env.JWT_VALIDADE || '30d',
  smsModo: process.env.SMS_MODO || 'consola',
  corsOrigens: (process.env.CORS_ORIGENS || '').split(',').map((s) => s.trim()).filter(Boolean),
  trustProxy: process.env.TRUST_PROXY === 'true',
  fuso: process.env.FUSO_HORARIO || 'Africa/Maputo',
  comissaoPercentagem: numero('COMISSAO_PERCENTAGEM', 10, { min: 0, max: 100 }),
  limiteDivida: numero('LIMITE_DIVIDA', 500, { min: 0 }),
  fatorRota: numero('FATOR_ROTA', 1.3, { min: 1, max: 3 }),
  arredondarPara: numero('ARREDONDAR_PARA', 5, { min: 1 }),
  ajustePrecoMax: numero('AJUSTE_PRECO_MAX', 0.3, { min: 0, max: 5 }),
  raioPedidosKm: numero('RAIO_PEDIDOS_KM', 5, { min: 0.1, max: 100 }),
  tempoMaxPedidoMin: numero('TEMPO_MAX_PEDIDO_MIN', 10, { min: 1, max: 1440 }),
  offlineAposMin: numero('OFFLINE_APOS_MIN', 10, { min: 1, max: 1440 }),
};

if (config.smsModo === 'consola' && producao) {
  console.warn('[aviso] SMS_MODO=consola em produção: os utilizadores não vão receber códigos por SMS.');
}
