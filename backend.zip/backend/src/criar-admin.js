import { pool } from './db.js';
import { normalizarTelefone } from './validar.js';

// Uso: npm run criar-admin -- "84 123 4567" "Nome do Administrador"
const [, , telefoneArg, ...nomeArg] = process.argv;
if (!telefoneArg) {
  console.error('Uso: npm run criar-admin -- "84 123 4567" "Nome do Administrador"');
  process.exit(1);
}

try {
  const telefone = normalizarTelefone(telefoneArg);
  const nome = nomeArg.join(' ').trim() || 'Administrador';
  const { rows } = await pool.query(
    `INSERT INTO utilizadores (nome, telefone, tipo) VALUES ($1, $2, 'admin')
     ON CONFLICT (telefone) DO UPDATE SET tipo = 'admin', estado = 'ativo'
     RETURNING id, nome, telefone`,
    [nome, telefone],
  );
  console.log(`Administrador pronto: ${rows[0].nome} (+${rows[0].telefone}). Entre na app com este número.`);
} catch (e) {
  console.error(e.message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
