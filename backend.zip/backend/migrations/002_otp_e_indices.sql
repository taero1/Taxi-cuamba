-- Códigos de verificação por SMS
CREATE TABLE otp_codigos (
    id          BIGSERIAL PRIMARY KEY,
    telefone    VARCHAR(20) NOT NULL,
    codigo_hash VARCHAR(64) NOT NULL,
    expira_em   TIMESTAMP NOT NULL,
    usado       BOOLEAN NOT NULL DEFAULT FALSE,
    tentativas  SMALLINT NOT NULL DEFAULT 0,
    criado_em   TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_otp_telefone ON otp_codigos(telefone, id DESC);

-- Um cliente só pode ter uma corrida ativa de cada vez
CREATE UNIQUE INDEX uma_corrida_ativa_por_cliente
    ON corridas(cliente_id)
    WHERE estado IN ('pedida', 'aceite', 'a_caminho', 'em_curso');

-- Um motorista só pode ter uma corrida em andamento de cada vez
CREATE UNIQUE INDEX uma_corrida_ativa_por_motorista
    ON corridas(motorista_id)
    WHERE motorista_id IS NOT NULL AND estado IN ('aceite', 'a_caminho', 'em_curso');

-- Procura rápida de pedidos abertos
CREATE INDEX idx_corridas_pedidas ON corridas(tipo_veiculo) WHERE estado = 'pedida';

-- Pesquisa de pontos de referência por nome
CREATE INDEX idx_pontos_nome ON pontos_referencia(LOWER(nome));
