-- =====================================================
-- App de Táxi e Gestão de Transportes - Base de Dados
-- PostgreSQL (latitude/longitude simples; PostGIS opcional)
-- =====================================================

CREATE TYPE tipo_utilizador AS ENUM ('cliente', 'motorista', 'admin');
CREATE TYPE estado_conta AS ENUM ('ativo', 'suspenso', 'bloqueado');
CREATE TYPE estado_verificacao AS ENUM ('pendente', 'aprovado', 'rejeitado');
CREATE TYPE tipo_veiculo AS ENUM ('taxi', 'moto_taxi', 'carrinha');
CREATE TYPE estado_corrida AS ENUM ('pedida', 'aceite', 'a_caminho', 'em_curso', 'concluida', 'cancelada');
CREATE TYPE metodo_pagamento AS ENUM ('dinheiro', 'mpesa', 'emola');
CREATE TYPE estado_pagamento AS ENUM ('pendente', 'pago', 'falhado');
CREATE TYPE estado_reclamacao AS ENUM ('aberta', 'em_analise', 'resolvida', 'rejeitada');

-- ---------- Utilizadores ----------
CREATE TABLE utilizadores (
    id              BIGSERIAL PRIMARY KEY,
    nome            VARCHAR(120) NOT NULL,
    telefone        VARCHAR(20)  NOT NULL UNIQUE,
    email           VARCHAR(120),
    senha_hash      VARCHAR(255),
    tipo            tipo_utilizador NOT NULL DEFAULT 'cliente',
    estado          estado_conta NOT NULL DEFAULT 'ativo',
    contacto_emergencia VARCHAR(20),
    criado_em       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- Motoristas ----------
CREATE TABLE motoristas (
    utilizador_id       BIGINT PRIMARY KEY REFERENCES utilizadores(id) ON DELETE CASCADE,
    numero_carta        VARCHAR(40) NOT NULL,
    validade_carta      DATE NOT NULL,
    numero_bi           VARCHAR(40),
    foto_url            VARCHAR(255),
    verificacao         estado_verificacao NOT NULL DEFAULT 'pendente',
    avaliacao_media     NUMERIC(3,2) NOT NULL DEFAULT 0,
    total_corridas      INTEGER NOT NULL DEFAULT 0,
    online              BOOLEAN NOT NULL DEFAULT FALSE,
    saldo_comissoes     NUMERIC(12,2) NOT NULL DEFAULT 0  -- quanto deve à plataforma
);

-- ---------- Veículos ----------
CREATE TABLE veiculos (
    id                  BIGSERIAL PRIMARY KEY,
    motorista_id        BIGINT NOT NULL REFERENCES motoristas(utilizador_id) ON DELETE CASCADE,
    tipo                tipo_veiculo NOT NULL,
    matricula           VARCHAR(20) NOT NULL UNIQUE,
    marca_modelo        VARCHAR(80),
    cor                 VARCHAR(30),
    lugares             SMALLINT NOT NULL DEFAULT 4,
    validade_seguro     DATE,
    validade_licenca    DATE,
    validade_inspecao   DATE,
    ativo               BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------- Zonas e pontos de referência ----------
CREATE TABLE zonas (
    id          BIGSERIAL PRIMARY KEY,
    nome        VARCHAR(100) NOT NULL,
    cidade      VARCHAR(100) NOT NULL
);

CREATE TABLE pontos_referencia (
    id          BIGSERIAL PRIMARY KEY,
    nome        VARCHAR(120) NOT NULL,   -- mercado, escola, hospital, etc.
    categoria   VARCHAR(40),
    latitude    NUMERIC(9,6) NOT NULL,
    longitude   NUMERIC(9,6) NOT NULL,
    zona_id     BIGINT REFERENCES zonas(id)
);

-- ---------- Tarifas ----------
CREATE TABLE tarifas (
    id              BIGSERIAL PRIMARY KEY,
    tipo_veiculo    tipo_veiculo NOT NULL,
    zona_origem_id  BIGINT REFERENCES zonas(id),
    zona_destino_id BIGINT REFERENCES zonas(id),
    preco_fixo      NUMERIC(10,2),          -- preço fixo entre zonas (opcional)
    taxa_base       NUMERIC(10,2) NOT NULL DEFAULT 0,
    preco_por_km    NUMERIC(10,2),
    ativo           BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------- Corridas ----------
CREATE TABLE corridas (
    id                  BIGSERIAL PRIMARY KEY,
    cliente_id          BIGINT NOT NULL REFERENCES utilizadores(id),
    motorista_id        BIGINT REFERENCES motoristas(utilizador_id),
    veiculo_id          BIGINT REFERENCES veiculos(id),
    tipo_veiculo        tipo_veiculo NOT NULL,
    origem_descricao    VARCHAR(200),
    origem_lat          NUMERIC(9,6) NOT NULL,
    origem_lng          NUMERIC(9,6) NOT NULL,
    origem_ponto_id     BIGINT REFERENCES pontos_referencia(id),
    destino_descricao   VARCHAR(200),
    destino_lat         NUMERIC(9,6),
    destino_lng         NUMERIC(9,6),
    destino_ponto_id    BIGINT REFERENCES pontos_referencia(id),
    distancia_km        NUMERIC(6,2),
    preco_estimado      NUMERIC(10,2),
    preco_final         NUMERIC(10,2),
    estado              estado_corrida NOT NULL DEFAULT 'pedida',
    pedida_em           TIMESTAMP NOT NULL DEFAULT NOW(),
    aceite_em           TIMESTAMP,
    iniciada_em         TIMESTAMP,
    concluida_em        TIMESTAMP,
    cancelada_em        TIMESTAMP,
    motivo_cancelamento VARCHAR(200),
    agendada_para       TIMESTAMP,           -- corridas agendadas
    codigo_partilha     VARCHAR(20) UNIQUE   -- partilha da viagem com contacto
);
CREATE INDEX idx_corridas_cliente ON corridas(cliente_id);
CREATE INDEX idx_corridas_motorista ON corridas(motorista_id);
CREATE INDEX idx_corridas_estado ON corridas(estado);

-- ---------- Pagamentos ----------
CREATE TABLE pagamentos (
    id                  BIGSERIAL PRIMARY KEY,
    corrida_id          BIGINT NOT NULL REFERENCES corridas(id),
    metodo              metodo_pagamento NOT NULL DEFAULT 'dinheiro',
    valor               NUMERIC(10,2) NOT NULL,
    estado              estado_pagamento NOT NULL DEFAULT 'pendente',
    referencia_transacao VARCHAR(80),
    pago_em             TIMESTAMP
);

-- ---------- Comissões ----------
CREATE TABLE comissoes (
    id              BIGSERIAL PRIMARY KEY,
    corrida_id      BIGINT NOT NULL UNIQUE REFERENCES corridas(id),
    motorista_id    BIGINT NOT NULL REFERENCES motoristas(utilizador_id),
    percentagem     NUMERIC(5,2) NOT NULL,
    valor           NUMERIC(10,2) NOT NULL,
    paga            BOOLEAN NOT NULL DEFAULT FALSE,
    paga_em         TIMESTAMP
);

-- ---------- Avaliações ----------
CREATE TABLE avaliacoes (
    id              BIGSERIAL PRIMARY KEY,
    corrida_id      BIGINT NOT NULL REFERENCES corridas(id),
    avaliador_id    BIGINT NOT NULL REFERENCES utilizadores(id),
    avaliado_id     BIGINT NOT NULL REFERENCES utilizadores(id),
    nota            SMALLINT NOT NULL CHECK (nota BETWEEN 1 AND 5),
    comentario      VARCHAR(300),
    criada_em       TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (corrida_id, avaliador_id)
);

-- ---------- Reclamações ----------
CREATE TABLE reclamacoes (
    id              BIGSERIAL PRIMARY KEY,
    corrida_id      BIGINT REFERENCES corridas(id),
    autor_id        BIGINT NOT NULL REFERENCES utilizadores(id),
    descricao       TEXT NOT NULL,
    estado          estado_reclamacao NOT NULL DEFAULT 'aberta',
    resolucao       TEXT,
    criada_em       TIMESTAMP NOT NULL DEFAULT NOW(),
    resolvida_em    TIMESTAMP
);

-- ---------- Localização em tempo real dos motoristas ----------
CREATE TABLE localizacoes_motoristas (
    id              BIGSERIAL PRIMARY KEY,
    motorista_id    BIGINT NOT NULL REFERENCES motoristas(utilizador_id) ON DELETE CASCADE,
    latitude        NUMERIC(9,6) NOT NULL,
    longitude       NUMERIC(9,6) NOT NULL,
    registado_em    TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_loc_motorista_tempo ON localizacoes_motoristas(motorista_id, registado_em DESC);

-- ---------- Alertas de emergência ----------
CREATE TABLE alertas_emergencia (
    id              BIGSERIAL PRIMARY KEY,
    corrida_id      BIGINT REFERENCES corridas(id),
    utilizador_id   BIGINT NOT NULL REFERENCES utilizadores(id),
    latitude        NUMERIC(9,6),
    longitude       NUMERIC(9,6),
    resolvido       BOOLEAN NOT NULL DEFAULT FALSE,
    criado_em       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ---------- Manutenção de veículos (gestão de frota) ----------
CREATE TABLE manutencoes (
    id              BIGSERIAL PRIMARY KEY,
    veiculo_id      BIGINT NOT NULL REFERENCES veiculos(id) ON DELETE CASCADE,
    descricao       VARCHAR(200) NOT NULL,
    custo           NUMERIC(10,2),
    data_manutencao DATE NOT NULL,
    proxima_data    DATE
);

-- ---------- Vista útil: documentos a expirar nos próximos 30 dias ----------
CREATE VIEW documentos_a_expirar AS
SELECT v.id AS veiculo_id, v.matricula, u.nome AS motorista,
       v.validade_seguro, v.validade_licenca, m.validade_carta
FROM veiculos v
JOIN motoristas m ON m.utilizador_id = v.motorista_id
JOIN utilizadores u ON u.id = m.utilizador_id
WHERE v.validade_seguro  <= CURRENT_DATE + 30
   OR v.validade_licenca <= CURRENT_DATE + 30
   OR m.validade_carta   <= CURRENT_DATE + 30;
