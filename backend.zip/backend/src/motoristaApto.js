import { config } from './config.js';
import { ErroHttp } from './erros.js';
import { hojeLocal } from './util.js';

// Perfil do motorista + o seu veículo ativo (na versão 1 cada motorista tem um veículo).
export async function carregarMotoristaEVeiculo(db, uid) {
  const { rows } = await db.query(
    `SELECT m.*,
            v.id AS veiculo_id, v.tipo AS veiculo_tipo, v.matricula, v.marca_modelo, v.cor, v.lugares,
            v.validade_seguro, v.validade_licenca, v.validade_inspecao
     FROM motoristas m
     LEFT JOIN veiculos v ON v.motorista_id = m.utilizador_id AND v.ativo
     WHERE m.utilizador_id = $1
     ORDER BY v.id DESC
     LIMIT 1`,
    [uid],
  );
  return rows[0] ?? null;
}

// Lista de razões pelas quais o motorista não pode trabalhar agora (vazia = pode).
export function motivosImpedimento(m) {
  const motivos = [];
  const hoje = hojeLocal();
  if (m.verificacao === 'pendente') motivos.push('A sua conta ainda aguarda aprovação');
  if (m.verificacao === 'rejeitado') motivos.push('O seu registo foi rejeitado. Contacte o apoio');
  if (m.saldo_comissoes > config.limiteDivida) {
    motivos.push(`Tem ${m.saldo_comissoes} MT de comissões em atraso (limite: ${config.limiteDivida} MT)`);
  }
  if (m.validade_carta < hoje) motivos.push('A carta de condução está caducada');
  if (!m.veiculo_id) {
    motivos.push('Não tem veículo ativo registado');
  } else {
    if (!m.validade_seguro || m.validade_seguro < hoje) motivos.push('O seguro do veículo está caducado ou em falta');
    if (!m.validade_licenca || m.validade_licenca < hoje) motivos.push('A licença do veículo está caducada ou em falta');
    if (m.validade_inspecao && m.validade_inspecao < hoje) motivos.push('A inspeção do veículo está caducada');
  }
  return motivos;
}

export async function motoristaApto(db, uid, { exigirOnline = false } = {}) {
  const m = await carregarMotoristaEVeiculo(db, uid);
  if (!m) throw new ErroHttp(403, 'Complete primeiro o perfil de motorista');
  const motivos = motivosImpedimento(m);
  if (motivos.length) throw new ErroHttp(403, motivos[0], { motivos });
  if (exigirOnline && !m.online) throw new ErroHttp(403, 'Fique online para trabalhar');
  return { motorista: m, veiculo: { id: m.veiculo_id, tipo: m.veiculo_tipo } };
}
