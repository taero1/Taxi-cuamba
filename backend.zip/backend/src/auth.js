import jwt from 'jsonwebtoken';
import { config } from './config.js';
import { query } from './db.js';
import { ErroHttp, asyncH } from './erros.js';

export function gerarToken(utilizador) {
  return jwt.sign({ tipo: utilizador.tipo }, config.jwtSegredo, {
    algorithm: 'HS256',
    subject: String(utilizador.id),
    expiresIn: config.jwtValidade,
  });
}

// Valida o token e carrega o utilizador atual da base de dados (para respeitar suspensões de imediato).
export const autenticar = asyncH(async (req, res, next) => {
  const [esquema, token] = (req.headers.authorization || '').split(' ');
  if (esquema !== 'Bearer' || !token) throw new ErroHttp(401, 'Sessão em falta');

  let payload;
  try {
    payload = jwt.verify(token, config.jwtSegredo, { algorithms: ['HS256'] });
  } catch {
    throw new ErroHttp(401, 'Sessão inválida ou expirada');
  }

  const { rows } = await query('SELECT id, nome, telefone, tipo, estado FROM utilizadores WHERE id = $1', [payload.sub]);
  const u = rows[0];
  if (!u) throw new ErroHttp(401, 'Sessão inválida');
  if (u.estado !== 'ativo') throw new ErroHttp(403, 'Conta suspensa ou bloqueada. Contacte o apoio.');
  req.utilizador = u;
  next();
});

export const exigirTipo =
  (...tipos) =>
  (req, res, next) => {
    if (!tipos.includes(req.utilizador.tipo)) return next(new ErroHttp(403, 'Sem permissão para esta ação'));
    return next();
  };
