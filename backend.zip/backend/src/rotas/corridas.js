import { Router } from 'express';
import { randomBytes } from 'node:crypto';
import { pool, tx } from '../db.js';
import { config } from '../config.js';
import { ErroHttp, asyncH } from '../erros.js';
import { autenticar, exigirTipo } from '../auth.js';
import { coordenadas, enumerado, idParam, inteiro, numero, texto } from '../validar.js';
import { haversineKm } from '../geo.js';
import { calcularPreco, resolverLocal } from '../preco.js';
import { motoristaApto } from '../motoristaApto.js';
import { arredondar2 } from '../util.js';

const router = Router();
router.use(autenticar);

const TIPOS_VEICULO = ['taxi', 'moto_taxi', 'carrinha'];
const METODOS = ['dinheiro', 'mpesa', 'emola'];
// Só dinheiro por agora: M-Pesa e e-Mola exigem integração com as operadoras (ver README).
const METODOS_ATIVOS = ['dinheiro'];
const ESTADOS_ATIVOS = ['pedida', 'aceite', 'a_caminho', 'em_curso'];
const DISTANCIA_MAXIMA_KM = 300;

const SQL_DETALHE = `
  SELECT c.id, c.cliente_id, c.motorista_id, c.veiculo_id, c.tipo_veiculo, c.estado,
         c.origem_descricao, c.origem_lat, c.origem_lng,
         c.destino_descricao, c.destino_lat, c.destino_lng,
         c.distancia_km, c.preco_estimado, c.preco_final,
         c.pedida_em, c.aceite_em, c.iniciada_em, c.concluida_em, c.cancelada_em, c.motivo_cancelamento,
         c.codigo_partilha,
         cu.nome AS cliente_nome, cu.telefone AS cliente_telefone,
         mu.nome AS motorista_nome, mu.telefone AS motorista_telefone,
         m.avaliacao_media AS motorista_avaliacao,
         v.matricula, v.marca_modelo, v.cor,
         p.metodo AS pagamento_metodo, p.estado AS pagamento_estado,
         loc.lat AS motorista_lat, loc.lng AS motorista_lng, loc.em AS motorista_localizacao_em
    FROM corridas c
    JOIN utilizadores cu ON cu.id = c.cliente_id
    LEFT JOIN utilizadores mu ON mu.id = c.motorista_id
    LEFT JOIN motoristas m ON m.utilizador_id = c.motorista_id
    LEFT JOIN veiculos v ON v.id = c.veiculo_id
    LEFT JOIN pagamentos p ON p.corrida_id = c.id
    LEFT JOIN LATERAL (
      SELECT l.latitude AS lat, l.longitude AS lng, l.registado_em AS em
        FROM localizacoes_motoristas l
       WHERE l.motorista_id = c.motorista_id
       ORDER BY l.registado_em DESC LIMIT 1
    ) loc ON TRUE`;

const carregarDetalhe = async (db, id) => (await db.query(`${SQL_DETALHE} WHERE c.id = $1`, [id])).rows[0] ?? null;

function paraResposta(c, utilizador) {
  const r = { ...c };
  if (!['aceite', 'a_caminho', 'em_curso'].includes(r.estado)) {
    delete r.motorista_lat;
    delete r.motorista_lng;
    delete r.motorista_localizacao_em;
  }
  if (utilizador.tipo === 'motorista') delete r.codigo_partilha;
  return r;
}

const eParticipante = (c, u) => u.tipo === 'admin' || c.cliente_id === u.id || c.motorista_id === u.id;

async function orcamento(db, b) {
  const tipo = enumerado(b.tipo_veiculo, 'tipo_veiculo', TIPOS_VEICULO);
  const origem = await resolverLocal(db, b.origem, 'origem');
  const destino = await resolverLocal(db, b.destino, 'destino');
  const km = arredondar2(haversineKm(origem.lat, origem.lng, destino.lat, destino.lng) * config.fatorRota);
  if (km < 0.1) throw new ErroHttp(400, 'A origem e o destino estão demasiado próximos');
  if (km > DISTANCIA_MAXIMA_KM) throw new ErroHttp(400, `A distância máxima é ${DISTANCIA_MAXIMA_KM} km`);
  const { preco, tarifa } = await calcularPreco(db, { tipo, km, zonaOrigem: origem.zona_id, zonaDestino: destino.zona_id });
  return { tipo, origem, destino, km, preco, tarifa };
}

// ---------- Consultas (antes de /:id) ----------

router.post(
  '/estimativa',
  asyncH(async (req, res) => {
    const o = await orcamento(pool, req.body ?? {});
    res.json({ tipo_veiculo: o.tipo, distancia_km: o.km, preco_estimado: o.preco, tipo_tarifa: o.tarifa });
  }),
);

// Corrida em andamento do utilizador (cliente ou motorista). A app pode consultar isto a cada poucos segundos.
router.get(
  '/atual',
  asyncH(async (req, res) => {
    const { rows } = await pool.query(
      `SELECT id FROM corridas
        WHERE (cliente_id = $1 OR motorista_id = $1) AND estado IN ('pedida', 'aceite', 'a_caminho', 'em_curso')
        ORDER BY id DESC LIMIT 1`,
      [req.utilizador.id],
    );
    if (!rows.length) return res.json({ corrida: null });
    const c = await carregarDetalhe(pool, rows[0].id);
    return res.json({ corrida: paraResposta(c, req.utilizador) });
  }),
);

router.get(
  '/historico',
  asyncH(async (req, res) => {
    const limite = inteiro(req.query.limite ?? 20, 'limite', { min: 1, max: 50 });
    const antes = req.query.antes_id ? idParam(req.query.antes_id, 'antes_id') : null;
    const { rows } = await pool.query(
      `${SQL_DETALHE}
        WHERE (c.cliente_id = $1 OR c.motorista_id = $1)
          AND c.estado IN ('concluida', 'cancelada')
          AND ($2::bigint IS NULL OR c.id < $2::bigint)
        ORDER BY c.id DESC
        LIMIT $3`,
      [req.utilizador.id, antes, limite],
    );
    res.json({ corridas: rows.map((c) => paraResposta(c, req.utilizador)) });
  }),
);

// ---------- Cliente ----------

router.post(
  '/',
  exigirTipo('cliente'),
  asyncH(async (req, res) => {
    const b = req.body ?? {};
    const metodo = enumerado(b.metodo_pagamento ?? 'dinheiro', 'metodo_pagamento', METODOS);
    if (!METODOS_ATIVOS.includes(metodo)) {
      throw new ErroHttp(422, `O pagamento por ${metodo === 'mpesa' ? 'M-Pesa' : 'e-Mola'} ainda não está disponível. Use dinheiro.`);
    }

    let id;
    try {
      id = await tx(async (db) => {
        const o = await orcamento(db, b);
        const { rows } = await db.query(
          `INSERT INTO corridas
             (cliente_id, tipo_veiculo, origem_descricao, origem_lat, origem_lng, origem_ponto_id,
              destino_descricao, destino_lat, destino_lng, destino_ponto_id,
              distancia_km, preco_estimado, codigo_partilha)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
           RETURNING id`,
          [
            req.utilizador.id, o.tipo,
            o.origem.descricao, o.origem.lat, o.origem.lng, o.origem.ponto_id,
            o.destino.descricao, o.destino.lat, o.destino.lng, o.destino.ponto_id,
            o.km, o.preco, randomBytes(8).toString('hex'),
          ],
        );
        await db.query('INSERT INTO pagamentos (corrida_id, metodo, valor) VALUES ($1, $2, $3)', [rows[0].id, metodo, o.preco]);
        return rows[0].id;
      });
    } catch (e) {
      if (e.code === '23505' && e.constraint === 'uma_corrida_ativa_por_cliente') {
        throw new ErroHttp(409, 'Já tem uma corrida em andamento');
      }
      throw e;
    }
    res.status(201).json({ corrida: paraResposta(await carregarDetalhe(pool, id), req.utilizador) });
  }),
);

router.post(
  '/:id/cancelar',
  exigirTipo('cliente'),
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const motivo = texto(req.body?.motivo, 'motivo', { max: 200, opcional: true }) ?? 'Cancelada pelo cliente';
    await tx(async (db) => {
      const { rows } = await db.query('SELECT estado FROM corridas WHERE id = $1 AND cliente_id = $2 FOR UPDATE', [id, req.utilizador.id]);
      if (!rows.length) throw new ErroHttp(404, 'Corrida não encontrada');
      if (!['pedida', 'aceite', 'a_caminho'].includes(rows[0].estado)) {
        throw new ErroHttp(409, 'Esta corrida já não pode ser cancelada');
      }
      await db.query(
        `UPDATE corridas SET estado = 'cancelada', cancelada_em = NOW(), motivo_cancelamento = $2 WHERE id = $1`,
        [id, motivo],
      );
      await db.query(
        `UPDATE pagamentos SET estado = 'falhado', referencia_transacao = 'corrida_cancelada' WHERE corrida_id = $1`,
        [id],
      );
    });
    res.json({ corrida: paraResposta(await carregarDetalhe(pool, id), req.utilizador) });
  }),
);

// ---------- Motorista ----------

router.post(
  '/:id/aceitar',
  exigirTipo('motorista'),
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const uid = req.utilizador.id;
    try {
      await tx(async (db) => {
        const { veiculo } = await motoristaApto(db, uid, { exigirOnline: true });
        const { rowCount } = await db.query(
          `UPDATE corridas
              SET motorista_id = $1, veiculo_id = $2, estado = 'aceite', aceite_em = NOW()
            WHERE id = $3 AND estado = 'pedida' AND tipo_veiculo = $4`,
          [uid, veiculo.id, id, veiculo.tipo],
        );
        if (!rowCount) throw new ErroHttp(409, 'Este pedido já não está disponível');
      });
    } catch (e) {
      if (e.code === '23505' && e.constraint === 'uma_corrida_ativa_por_motorista') {
        throw new ErroHttp(409, 'Já tem uma corrida em andamento');
      }
      throw e;
    }
    res.json({ corrida: paraResposta(await carregarDetalhe(pool, id), req.utilizador) });
  }),
);

// O motorista desiste: o pedido volta à fila para outro motorista aceitar.
router.post(
  '/:id/desistir',
  exigirTipo('motorista'),
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const { rowCount } = await pool.query(
      `UPDATE corridas
          SET estado = 'pedida', motorista_id = NULL, veiculo_id = NULL, aceite_em = NULL, pedida_em = NOW()
        WHERE id = $1 AND motorista_id = $2 AND estado IN ('aceite', 'a_caminho')`,
      [id, req.utilizador.id],
    );
    if (!rowCount) throw new ErroHttp(409, 'Não é possível desistir desta corrida');
    res.json({ ok: true });
  }),
);

function transicao(nome, deEstados, paraEstado, extraSet = '') {
  router.post(
    `/:id/${nome}`,
    exigirTipo('motorista'),
    asyncH(async (req, res) => {
      const id = idParam(req.params.id);
      const { rowCount } = await pool.query(
        `UPDATE corridas SET estado = $3 ${extraSet}
          WHERE id = $1 AND motorista_id = $2 AND estado = ANY($4::estado_corrida[])`,
        [id, req.utilizador.id, paraEstado, deEstados],
      );
      if (!rowCount) throw new ErroHttp(409, 'Esta ação não é possível no estado atual da corrida');
      res.json({ corrida: paraResposta(await carregarDetalhe(pool, id), req.utilizador) });
    }),
  );
}
transicao('a-caminho', ['aceite'], 'a_caminho');
transicao('iniciar', ['aceite', 'a_caminho'], 'em_curso', ', iniciada_em = NOW()');

router.post(
  '/:id/concluir',
  exigirTipo('motorista'),
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const uid = req.utilizador.id;
    const { comissao, saldo } = await tx(async (db) => {
      const { rows } = await db.query(
        'SELECT estado, preco_estimado FROM corridas WHERE id = $1 AND motorista_id = $2 FOR UPDATE',
        [id, uid],
      );
      if (!rows.length) throw new ErroHttp(404, 'Corrida não encontrada');
      const c = rows[0];
      if (c.estado !== 'em_curso') throw new ErroHttp(409, 'Só pode concluir uma corrida em curso');

      const maximo = arredondar2(c.preco_estimado * (1 + config.ajustePrecoMax));
      const precoFinal = req.body?.preco_final === undefined
        ? c.preco_estimado
        : numero(req.body.preco_final, 'preco_final', { min: 0.01 });
      if (precoFinal > maximo) {
        throw new ErroHttp(422, `O preço final não pode ultrapassar ${maximo} MT (estimado: ${c.preco_estimado} MT)`);
      }

      const valor = arredondar2((precoFinal * config.comissaoPercentagem) / 100);
      await db.query(`UPDATE corridas SET estado = 'concluida', concluida_em = NOW(), preco_final = $2 WHERE id = $1`, [id, precoFinal]);
      await db.query(
        `UPDATE pagamentos
            SET valor = $2,
                estado = CASE WHEN metodo = 'dinheiro' THEN 'pago'::estado_pagamento ELSE estado END,
                pago_em = CASE WHEN metodo = 'dinheiro' THEN NOW() ELSE pago_em END
          WHERE corrida_id = $1`,
        [id, precoFinal],
      );
      await db.query(
        'INSERT INTO comissoes (corrida_id, motorista_id, percentagem, valor) VALUES ($1, $2, $3, $4)',
        [id, uid, config.comissaoPercentagem, valor],
      );
      const { rows: m } = await db.query(
        `UPDATE motoristas SET saldo_comissoes = saldo_comissoes + $2, total_corridas = total_corridas + 1
          WHERE utilizador_id = $1 RETURNING saldo_comissoes`,
        [uid, valor],
      );
      return { comissao: { percentagem: config.comissaoPercentagem, valor }, saldo: m[0].saldo_comissoes };
    });
    res.json({
      corrida: paraResposta(await carregarDetalhe(pool, id), req.utilizador),
      comissao,
      saldo_comissoes: saldo,
    });
  }),
);

// ---------- Cliente e motorista ----------

router.get(
  '/:id',
  asyncH(async (req, res) => {
    const c = await carregarDetalhe(pool, idParam(req.params.id));
    if (!c || !eParticipante(c, req.utilizador)) throw new ErroHttp(404, 'Corrida não encontrada');
    res.json({ corrida: paraResposta(c, req.utilizador) });
  }),
);

router.post(
  '/:id/avaliar',
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const nota = inteiro(req.body?.nota, 'nota', { min: 1, max: 5 });
    const comentario = texto(req.body?.comentario, 'comentario', { max: 300, opcional: true });
    const u = req.utilizador;

    await tx(async (db) => {
      const { rows } = await db.query('SELECT cliente_id, motorista_id, estado FROM corridas WHERE id = $1', [id]);
      const c = rows[0];
      if (!c || (c.cliente_id !== u.id && c.motorista_id !== u.id)) throw new ErroHttp(404, 'Corrida não encontrada');
      if (c.estado !== 'concluida') throw new ErroHttp(409, 'Só pode avaliar corridas concluídas');

      const avaliado = c.cliente_id === u.id ? c.motorista_id : c.cliente_id;
      const ins = await db.query(
        `INSERT INTO avaliacoes (corrida_id, avaliador_id, avaliado_id, nota, comentario)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (corrida_id, avaliador_id) DO NOTHING
         RETURNING id`,
        [id, u.id, avaliado, nota, comentario],
      );
      if (!ins.rowCount) throw new ErroHttp(409, 'Já avaliou esta corrida');

      await db.query(
        `UPDATE motoristas
            SET avaliacao_media = COALESCE((SELECT ROUND(AVG(nota)::numeric, 2) FROM avaliacoes WHERE avaliado_id = $1), 0)
          WHERE utilizador_id = $1`,
        [avaliado],
      );
    });
    res.status(201).json({ ok: true });
  }),
);

// Botão de emergência: regista o alerta para a administração tratar.
router.post(
  '/:id/emergencia',
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const u = req.utilizador;
    const { rows } = await pool.query('SELECT cliente_id, motorista_id, estado FROM corridas WHERE id = $1', [id]);
    const c = rows[0];
    if (!c || (c.cliente_id !== u.id && c.motorista_id !== u.id)) throw new ErroHttp(404, 'Corrida não encontrada');
    if (!['aceite', 'a_caminho', 'em_curso'].includes(c.estado)) {
      throw new ErroHttp(409, 'O alerta só pode ser enviado durante uma corrida');
    }
    let lat = null;
    let lng = null;
    if (req.body?.lat !== undefined || req.body?.lng !== undefined) ({ lat, lng } = coordenadas(req.body.lat, req.body.lng));

    await pool.query(
      'INSERT INTO alertas_emergencia (corrida_id, utilizador_id, latitude, longitude) VALUES ($1, $2, $3, $4)',
      [id, u.id, lat, lng],
    );
    res.status(201).json({
      ok: true,
      mensagem: 'Alerta enviado à administração. Se estiver em perigo imediato, contacte também as autoridades locais.',
    });
  }),
);

export { ESTADOS_ATIVOS };
export default router;
