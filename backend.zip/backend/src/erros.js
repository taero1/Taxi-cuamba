export class ErroHttp extends Error {
  constructor(status, mensagem, extra = {}) {
    super(mensagem);
    this.status = status;
    this.extra = extra;
  }
}

// Express 4 não apanha erros de funções async; este invólucro encaminha-os para o tratador.
export const asyncH = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export function naoEncontrado(req, res) {
  res.status(404).json({ erro: 'Rota não encontrada' });
}

// eslint-disable-next-line no-unused-vars
export function tratadorErros(err, req, res, _next) {
  if (err instanceof ErroHttp) {
    return res.status(err.status).json({ erro: err.message, ...err.extra });
  }
  if (err.type === 'entity.parse.failed') return res.status(400).json({ erro: 'JSON inválido' });
  if (err.type === 'entity.too.large') return res.status(413).json({ erro: 'Pedido demasiado grande' });
  console.error('[erro]', err);
  return res.status(500).json({ erro: 'Erro interno do servidor' });
}
