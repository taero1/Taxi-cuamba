import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { pool, tx } from '../db.js';
import { config } from '../config.js';
import { ErroHttp, asyncH } from '../erros.js';
import { autenticar, exigirTipo } from '../auth.js';
import { booleano, coordenadas, dataISO, enumerado, inteiro, texto, urlHttps } from '../validar.js';
import { sqlDistKm } from '../geo.js';
import { carregarMotoristaEVeiculo, motivosImpedimento, motoristaApto } from '../motoristaApto.js';
import { hojeLocal, montarSet, sqlInicioPeriodo } from '../util.js';

const router = Router();
router.use(autenticar, exigirTipo('motorista'));

const TIPOS_VEICULO = ['taxi', 'moto_taxi', 'carrinha'];
const LUGARES_PADRAO = { taxi: 4, moto_taxi: 1, carrinha: 15 };

const limiteLocalizacao = rateLimit({
  windowMs: 60_000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => String(req.utilizador.id), // por motorista (várias pessoas partilham o mesmo IP em redes móveis)
  message: { erro: 'Envie a localização com menos frequência' },
});

const matricula = (v) => texto(v, 'matricula', { min: 3, max: 20 }).toUpperCase().replace(/\s+/g, ' ');

function perfilParaResposta(m) {
  const motivos = motivosImpedimento(m);
  return {
    verificacao: m.verificacao,
    online: m.online,
    avaliacao_media: m.avaliacao_media,
    total_corridas: m.total_corridas,
    saldo_comissoes: m.saldo_comissoes,
    limite_divida: config.limiteDivida,
    carta: { numero: m.numero_carta, validade: m.validade_carta },
    numero_bi: m.numero_bi,
    foto_url: m.foto_url,
    veiculo: m.veiculo_id
      ? {
          id: m.veiculo_id,
          tipo: m.veiculo_tipo,
          matricula: m.matricula,
          marca_modelo: m.marca_modelo,
          cor: m.cor,
          lugares: m.lugares,
          validade_seguro: m.validade_seguro,
          validade_licenca: m.validade_licenca,
          validade_inspecao: m.validade_inspecao,
        }
      : null,
    pode_trabalhar: motivos.length === 0,
    motivos,
  };
}

async function exigirSemCorridaAtiva(db, uid) {
  const { rowCount } = await db.query(
    `SELECT 1 FROM corridas WHERE motorista_id = $1 AND estado IN ('aceite', 'a_caminho', 'em_curso')`,
    [uid],
  );
  if (rowCount) throw new ErroHttp(409, 'Termine a corrida em andamento primeiro');
}

// ---------- Perfil e documentos ----------

router.post(
  '/perfil',
  asyncH(async (req, res) => {
    const uid = req.utilizador.id;
    const b = req.body ?? {};
    const v = b.veiculo ?? {};
    const tipo = enumerado(v.tipo, 'veiculo.tipo', TIPOS_VEICULO);

    const motorista = {
      numero_carta: texto(b.numero_carta, 'numero_carta', { max: 40 }),
      validade_carta: dataISO(b.validade_carta, 'validade_carta'),
      numero_bi: texto(b.numero_bi, 'numero_bi', { max: 40, opcional: true }),
      foto_url: urlHttps(b.foto_url, 'foto_url'),
    };
    const veiculo = {
      tipo,
      matricula: matricula(v.matricula),
      marca_modelo: texto(v.marca_modelo, 'veiculo.marca_modelo', { max: 80, opcional: true }),
      cor: texto(v.cor, 'veiculo.cor', { max: 30, opcional: true }),
      lugares: inteiro(v.lugares ?? LUGARES_PADRAO[tipo], 'veiculo.lugares', { min: 1, max: 30 }),
      validade_seguro: dataISO(v.validade_seguro, 'veiculo.validade_seguro'),
      validade_licenca: dataISO(v.validade_licenca, 'veiculo.validade_licenca'),
      validade_inspecao: dataISO(v.validade_inspecao, 'veiculo.validade_inspecao', { opcional: true }),
    };

    try {
      await tx(async (db) => {
        await db.query(
          `INSERT INTO motoristas (utilizador_id, numero_carta, validade_carta, numero_bi, foto_url)
           VALUES ($1, $2, $3, $4, $5)`,
          [uid, motorista.numero_carta, motorista.validade_carta, motorista.numero_bi, motorista.foto_url],
        );
        await db.query(
          `INSERT INTO veiculos
             (motorista_id, tipo, matricula, marca_modelo, cor, lugares, validade_seguro, validade_licenca, validade_inspecao)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
          [uid, veiculo.tipo, veiculo.matricula, veiculo.marca_modelo, veiculo.cor, veiculo.lugares,
           veiculo.validade_seguro, veiculo.validade_licenca, veiculo.validade_inspecao],
        );
      });
    } catch (e) {
      if (e.code === '23505' && e.constraint === 'motoristas_pkey') throw new ErroHttp(409, 'Já tem um perfil de motorista');
      if (e.code === '23505' && e.constraint === 'veiculos_matricula_key') throw new ErroHttp(409, 'Esta matrícula já está registada');
      throw e;
    }
    res.status(201).json({ perfil: perfilParaResposta(await carregarMotoristaEVeiculo(pool, uid)) });
  }),
);

router.get(
  '/perfil',
  asyncH(async (req, res) => {
    const m = await carregarMotoristaEVeiculo(pool, req.utilizador.id);
    if (!m) throw new ErroHttp(404, 'Ainda não tem perfil de motorista');
    res.json({ perfil: perfilParaResposta(m) });
  }),
);

// Alterar dados da carta ou do BI volta a pôr a conta "pendente" até a administração conferir os documentos.
router.put(
  '/perfil',
  asyncH(async (req, res) => {
    const uid = req.utilizador.id;
    const b = req.body ?? {};
    const campos = {
      numero_carta: b.numero_carta === undefined ? undefined : texto(b.numero_carta, 'numero_carta', { max: 40 }),
      validade_carta: b.validade_carta === undefined ? undefined : dataISO(b.validade_carta, 'validade_carta'),
      numero_bi: b.numero_bi === undefined ? undefined : texto(b.numero_bi, 'numero_bi', { max: 40, opcional: true }),
      foto_url: b.foto_url === undefined ? undefined : urlHttps(b.foto_url, 'foto_url'),
    };

    await tx(async (db) => {
      const { rows } = await db.query('SELECT * FROM motoristas WHERE utilizador_id = $1 FOR UPDATE', [uid]);
      if (!rows.length) throw new ErroHttp(404, 'Ainda não tem perfil de motorista');
      await exigirSemCorridaAtiva(db, uid);
      const atual = rows[0];
      const { chaves, set, valores } = montarSet(campos, 2);
      if (!chaves.length) throw new ErroHttp(400, 'Nada para atualizar');
      const sensivel = ['numero_carta', 'validade_carta', 'numero_bi'].some((k) => campos[k] !== undefined && campos[k] !== atual[k]);
      await db.query(
        `UPDATE motoristas SET ${set}${sensivel ? ", verificacao = 'pendente', online = FALSE" : ''} WHERE utilizador_id = $1`,
        [uid, ...valores],
      );
    });
    res.json({ perfil: perfilParaResposta(await carregarMotoristaEVeiculo(pool, uid)) });
  }),
);

router.put(
  '/veiculo',
  asyncH(async (req, res) => {
    const uid = req.utilizador.id;
    const b = req.body ?? {};
    const campos = {
      tipo: b.tipo === undefined ? undefined : enumerado(b.tipo, 'tipo', TIPOS_VEICULO),
      matricula: b.matricula === undefined ? undefined : matricula(b.matricula),
      marca_modelo: b.marca_modelo === undefined ? undefined : texto(b.marca_modelo, 'marca_modelo', { max: 80, opcional: true }),
      cor: b.cor === undefined ? undefined : texto(b.cor, 'cor', { max: 30, opcional: true }),
      lugares: b.lugares === undefined ? undefined : inteiro(b.lugares, 'lugares', { min: 1, max: 30 }),
      validade_seguro: b.validade_seguro === undefined ? undefined : dataISO(b.validade_seguro, 'validade_seguro'),
      validade_licenca: b.validade_licenca === undefined ? undefined : dataISO(b.validade_licenca, 'validade_licenca'),
      validade_inspecao: b.validade_inspecao === undefined ? undefined : dataISO(b.validade_inspecao, 'validade_inspecao', { opcional: true }),
    };

    try {
      await tx(async (db) => {
        const { rows } = await db.query(
          'SELECT * FROM veiculos WHERE motorista_id = $1 AND ativo ORDER BY id DESC LIMIT 1 FOR UPDATE',
          [uid],
        );
        if (!rows.length) throw new ErroHttp(404, 'Não tem veículo ativo registado');
        await exigirSemCorridaAtiva(db, uid);
        const atual = rows[0];
        const { chaves, set, valores } = montarSet(campos, 2);
        if (!chaves.length) throw new ErroHttp(400, 'Nada para atualizar');
        await db.query(`UPDATE veiculos SET ${set} WHERE id = $1`, [atual.id, ...valores]);

        const sensiveis = ['tipo', 'matricula', 'validade_seguro', 'validade_licenca', 'validade_inspecao'];
        if (sensiveis.some((k) => campos[k] !== undefined && campos[k] !== atual[k])) {
          await db.query(`UPDATE motoristas SET verificacao = 'pendente', online = FALSE WHERE utilizador_id = $1`, [uid]);
        }
      });
    } catch (e) {
      if (e.code === '23505' && e.constraint === 'veiculos_matricula_key') throw new ErroHttp(409, 'Esta matrícula já está registada');
      throw e;
    }
    res.json({ perfil: perfilParaResposta(await carregarMotoristaEVeiculo(pool, uid)) });
  }),
);

// ---------- Trabalho ----------

router.post(
  '/estado',
  asyncH(async (req, res) => {
    const uid = req.utilizador.id;
    const online = booleano(req.body?.online, 'online');

    if (online) {
      const { lat, lng } = coordenadas(req.body?.lat, req.body?.lng);
      await tx(async (db) => {
        await motoristaApto(db, uid);
        await db.query('INSERT INTO localizacoes_motoristas (motorista_id, latitude, longitude) VALUES ($1, $2, $3)', [uid, lat, lng]);
        await db.query('UPDATE motoristas SET online = TRUE WHERE utilizador_id = $1', [uid]);
      });
    } else {
      await exigirSemCorridaAtiva(pool, uid);
      await pool.query('UPDATE motoristas SET online = FALSE WHERE utilizador_id = $1', [uid]);
    }
    res.json({ online });
  }),
);

router.post(
  '/localizacao',
  limiteLocalizacao,
  asyncH(async (req, res) => {
    const { lat, lng } = coordenadas(req.body?.lat, req.body?.lng);
    const { rowCount } = await pool.query(
      `INSERT INTO localizacoes_motoristas (motorista_id, latitude, longitude)
       SELECT utilizador_id, $2, $3 FROM motoristas WHERE utilizador_id = $1 AND online`,
      [req.utilizador.id, lat, lng],
    );
    if (!rowCount) throw new ErroHttp(409, 'Fique online para enviar a localização');
    res.json({ ok: true });
  }),
);

// Pedidos abertos perto do motorista, do tipo do seu veículo, do mais próximo para o mais distante.
router.get(
  '/pedidos',
  asyncH(async (req, res) => {
    const uid = req.utilizador.id;
    const { veiculo } = await motoristaApto(pool, uid, { exigirOnline: true });

    const { rows: loc } = await pool.query(
      `SELECT latitude, longitude FROM localizacoes_motoristas
        WHERE motorista_id = $1 AND registado_em > NOW() - INTERVAL '5 minutes'
        ORDER BY registado_em DESC LIMIT 1`,
      [uid],
    );
    if (!loc.length) throw new ErroHttp(409, 'Envie a sua localização para ver pedidos');

    const { rows } = await pool.query(
      `SELECT id, tipo_veiculo, origem_descricao, origem_lat, origem_lng,
              destino_descricao, destino_lat, destino_lng, distancia_km, preco_estimado, pedida_em,
              ROUND(d::numeric, 2) AS distancia_ate_cliente_km
         FROM (
           SELECT c.*, ${sqlDistKm('c.origem_lat', 'c.origem_lng', '$2', '$3')} AS d
             FROM corridas c
            WHERE c.estado = 'pedida' AND c.tipo_veiculo = $1::tipo_veiculo
         ) t
        WHERE d <= $4
        ORDER BY d
        LIMIT 20`,
      [veiculo.tipo, loc[0].latitude, loc[0].longitude, config.raioPedidosKm],
    );
    res.json({ pedidos: rows });
  }),
);

router.get(
  '/ganhos',
  asyncH(async (req, res) => {
    const unidade = { dia: 'day', semana: 'week', mes: 'month' }[req.query.periodo ?? 'dia'];
    if (!unidade) throw new ErroHttp(400, 'O período deve ser: dia, semana ou mes');

    const { rows } = await pool.query(
      `SELECT COUNT(*) AS corridas,
              COALESCE(SUM(c.preco_final), 0) AS bruto,
              COALESCE(SUM(co.valor), 0) AS comissoes
         FROM corridas c
         LEFT JOIN comissoes co ON co.corrida_id = c.id
        WHERE c.motorista_id = $1 AND c.estado = 'concluida'
          AND c.concluida_em >= ${sqlInicioPeriodo('$2', '$3')}`,
      [req.utilizador.id, unidade, config.fuso],
    );
    const { rows: m } = await pool.query('SELECT saldo_comissoes FROM motoristas WHERE utilizador_id = $1', [req.utilizador.id]);
    const r = rows[0];
    res.json({
      periodo: req.query.periodo ?? 'dia',
      desde: hojeLocal(),
      corridas: r.corridas,
      bruto: r.bruto,
      comissoes: r.comissoes,
      liquido: Math.round((r.bruto - r.comissoes) * 100) / 100,
      saldo_comissoes_por_pagar: m[0]?.saldo_comissoes ?? 0,
      limite_divida: config.limiteDivida,
    });
  }),
);

export default router;
