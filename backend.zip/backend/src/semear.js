import { pool } from './db.js';

// Dados de exemplo para testar: uma zona, alguns pontos de referência e tarifas gerais.
// Os nomes, coordenadas e preços são EXEMPLOS (centro de Cuamba, aproximado) — edite pelo painel/admin ou aqui.
const cidade = 'Cuamba';

try {
  const { rows: z } = await pool.query('SELECT id FROM zonas WHERE nome = $1 AND cidade = $2', ['Centro', cidade]);
  let zonaId = z[0]?.id;
  if (!zonaId) {
    ({ rows: [{ id: zonaId }] } = await pool.query('INSERT INTO zonas (nome, cidade) VALUES ($1, $2) RETURNING id', ['Centro', cidade]));
  }

  const pontos = [
    ['Mercado central (exemplo)', 'mercado', -14.8035, 36.5380],
    ['Hospital (exemplo)', 'hospital', -14.8090, 36.5450],
    ['Estação (exemplo)', 'estacao', -14.8010, 36.5330],
  ];
  for (const [nome, categoria, lat, lng] of pontos) {
    await pool.query(
      `INSERT INTO pontos_referencia (nome, categoria, latitude, longitude, zona_id)
       SELECT $1::text, $2::text, $3::numeric, $4::numeric, $5::bigint
        WHERE NOT EXISTS (SELECT 1 FROM pontos_referencia WHERE nome = $1::text)`,
      [nome, categoria, lat, lng, zonaId],
    );
  }

  const tarifas = [
    ['taxi', 50, 25],
    ['moto_taxi', 20, 12],
    ['carrinha', 80, 30],
  ];
  for (const [tipo, base, porKm] of tarifas) {
    await pool.query(
      `INSERT INTO tarifas (tipo_veiculo, taxa_base, preco_por_km)
       SELECT $1::tipo_veiculo, $2::numeric, $3::numeric
        WHERE NOT EXISTS (SELECT 1 FROM tarifas WHERE tipo_veiculo = $1::tipo_veiculo AND zona_origem_id IS NULL AND ativo)`,
      [tipo, base, porKm],
    );
  }
  console.log('Dados de exemplo criados. Ajuste as tarifas e os pontos de referência à realidade da sua cidade.');
} finally {
  await pool.end();
}
