-- Registo de todas as correções de preço feitas pela administração (disputas)
CREATE TABLE ajustes_preco (
    id          BIGSERIAL PRIMARY KEY,
    corrida_id  BIGINT NOT NULL REFERENCES corridas(id),
    admin_id    BIGINT NOT NULL REFERENCES utilizadores(id),
    preco_antigo NUMERIC(10,2),
    preco_novo  NUMERIC(10,2) NOT NULL,
    motivo      VARCHAR(200) NOT NULL,
    criado_em   TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ajustes_corrida ON ajustes_preco(corrida_id);
