import { Router } from 'express';
import { pool, tx } from '../db.js';
import { config } from '../config.js';
import { ErroHttp, asyncH } from '../erros.js';
import { autenticar, exigirTipo } from '../auth.js';
import {
  coordenadas, dataISO, enumerado, idParam, inteiro, numero, texto,
} from '../validar.js';
import { csv, hojeLocal, montarSet, sqlInicioPeriodo } from '../util.js';

const router = Router();
router.use(autenticar, exigirTipo('admin'));

const TIPOS_VEICULO = ['taxi', 'moto_taxi', 'carrinha'];

// ---------- Dashboard e mapa ----------

router.get(
  '/dashboard',
  asyncH(async (req, res) => {
    const inicioDia = sqlInicioPeriodo('$1', '$2');
    const [corridas, motoristas, reclamacoes, emergencias, pendentes] = await Promise.all([
      pool.query(
        `SELECT COUNT(*) FILTER (WHERE estado = 'concluida') AS concluidas,
                COUNT(*) FILTER (WHERE estado = 'cancelada') AS canceladas,
                COUNT(*) FILTER (WHERE estado IN ('pedida', 'aceite', 'a_caminho', 'em_curso')) AS ativas,
                COALESCE(SUM(preco_final) FILTER (WHERE estado = 'concluida'), 0) AS movimento
           FROM corridas WHERE pedida_em >= ${inicioDia}`,
        ['day', config.fuso],
      ),
      pool.query(`SELECT COUNT(*) FILTER (WHERE online) AS online, COUNT(*) AS total FROM motoristas WHERE verificacao = 'aprovado'`),
      pool.query(`SELECT COUNT(*) AS n FROM reclamacoes WHERE estado IN ('aberta', 'em_analise')`),
      pool.query('SELECT COUNT(*) AS n FROM alertas_emergencia WHERE NOT resolvido'),
      pool.query(`SELECT COUNT(*) AS n FROM motoristas WHERE verificacao = 'pendente'`),
    ]);
    const comissoes = await pool.query(
      `SELECT COALESCE(SUM(valor), 0) AS hoje FROM comissoes co JOIN corridas c ON c.id = co.corrida_id
        WHERE c.concluida_em >= ${inicioDia}`,
      ['day', config.fuso],
    );
    res.json({
      hoje: hojeLocal(),
      corridas: corridas.rows[0],
      receita_plataforma_hoje: comissoes.rows[0].hoje,
      motoristas_online: motoristas.rows[0].online,
      motoristas_aprovados: motoristas.rows[0].total,
      motoristas_por_aprovar: pendentes.rows[0].n,
      reclamacoes_abertas: reclamacoes.rows[0].n,
      emergencias_por_resolver: emergencias.rows[0].n,
    });
  }),
);

router.get(
  '/mapa',
  asyncH(async (req, res) => {
    const [motoristas, corridas] = await Promise.all([
      pool.query(
        `SELECT m.utilizador_id AS id, u.nome, v.tipo, v.matricula, loc.lat, loc.lng, loc.em AS atualizado_em,
                EXISTS (SELECT 1 FROM corridas c WHERE c.motorista_id = m.utilizador_id
                         AND c.estado IN ('aceite', 'a_caminho', 'em_curso')) AS ocupado
           FROM motoristas m
           JOIN utilizadores u ON u.id = m.utilizador_id
           LEFT JOIN veiculos v ON v.motorista_id = m.utilizador_id AND v.ativo
           JOIN LATERAL (
             SELECT l.latitude AS lat, l.longitude AS lng, l.registado_em AS em
               FROM localizacoes_motoristas l WHERE l.motorista_id = m.utilizador_id
              ORDER BY l.registado_em DESC LIMIT 1
           ) loc ON TRUE
          WHERE m.online`,
      ),
      pool.query(
        `SELECT id, estado, tipo_veiculo, origem_lat, origem_lng, destino_lat, destino_lng, motorista_id, pedida_em
           FROM corridas WHERE estado IN ('pedida', 'aceite', 'a_caminho', 'em_curso') ORDER BY id DESC LIMIT 200`,
      ),
    ]);
    res.json({ motoristas: motoristas.rows, corridas: corridas.rows });
  }),
);

// ---------- Motoristas e veículos ----------

router.get(
  '/motoristas',
  asyncH(async (req, res) => {
    const estado = req.query.verificacao ? enumerado(req.query.verificacao, 'verificacao', ['pendente', 'aprovado', 'rejeitado']) : null;
    const { rows } = await pool.query(
      `SELECT m.utilizador_id AS id, u.nome, u.telefone, u.estado AS estado_conta,
              m.verificacao, m.online, m.avaliacao_media, m.total_corridas, m.saldo_comissoes,
              m.numero_carta, m.validade_carta, m.numero_bi, m.foto_url,
              v.id AS veiculo_id, v.tipo, v.matricula, v.marca_modelo,
              v.validade_seguro, v.validade_licenca, v.validade_inspecao
         FROM motoristas m
         JOIN utilizadores u ON u.id = m.utilizador_id
         LEFT JOIN veiculos v ON v.motorista_id = m.utilizador_id AND v.ativo
        WHERE ($1::text IS NULL OR m.verificacao::text = $1)
        ORDER BY m.utilizador_id DESC
        LIMIT 200`,
      [estado],
    );
    res.json({ motoristas: rows });
  }),
);

router.post(
  '/motoristas/:id/verificacao',
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const estado = enumerado(req.body?.estado, 'estado', ['aprovado', 'rejeitado', 'pendente']);
    const { rowCount } = await pool.query(
      `UPDATE motoristas SET verificacao = $2, online = CASE WHEN $2 = 'aprovado' THEN online ELSE FALSE END
        WHERE utilizador_id = $1`,
      [id, estado],
    );
    if (!rowCount) throw new ErroHttp(404, 'Motorista não encontrado');
    res.json({ ok: true, estado });
  }),
);

router.post(
  '/utilizadores/:id/estado',
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const estado = enumerado(req.body?.estado, 'estado', ['ativo', 'suspenso', 'bloqueado']);
    if (id === req.utilizador.id) throw new ErroHttp(400, 'Não pode alterar o estado da sua própria conta');
    await tx(async (db) => {
      const { rowCount } = await db.query('UPDATE utilizadores SET estado = $2 WHERE id = $1', [id, estado]);
      if (!rowCount) throw new ErroHttp(404, 'Utilizador não encontrado');
      if (estado !== 'ativo') await db.query('UPDATE motoristas SET online = FALSE WHERE utilizador_id = $1', [id]);
    });
    res.json({ ok: true, estado });
  }),
);

router.get(
  '/veiculos',
  asyncH(async (req, res) => {
    const { rows } = await pool.query(
      `SELECT v.*, u.nome AS motorista
         FROM veiculos v JOIN utilizadores u ON u.id = v.motorista_id
        ORDER BY v.id DESC LIMIT 300`,
    );
    res.json({ veiculos: rows });
  }),
);

router.get(
  '/documentos-a-expirar',
  asyncH(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM documentos_a_expirar ORDER BY motorista');
    res.json({ documentos: rows });
  }),
);

router.post(
  '/veiculos/:id/manutencoes',
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const b = req.body ?? {};
    const { rows: v } = await pool.query('SELECT 1 FROM veiculos WHERE id = $1', [id]);
    if (!v.length) throw new ErroHttp(404, 'Veículo não encontrado');
    const { rows } = await pool.query(
      `INSERT INTO manutencoes (veiculo_id, descricao, custo, data_manutencao, proxima_data)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [
        id,
        texto(b.descricao, 'descricao', { max: 200 }),
        numero(b.custo, 'custo', { min: 0, opcional: true }),
        dataISO(b.data_manutencao, 'data_manutencao'),
        dataISO(b.proxima_data, 'proxima_data', { opcional: true }),
      ],
    );
    res.status(201).json({ manutencao: rows[0] });
  }),
);

router.get(
  '/veiculos/:id/manutencoes',
  asyncH(async (req, res) => {
    const { rows } = await pool.query(
      'SELECT * FROM manutencoes WHERE veiculo_id = $1 ORDER BY data_manutencao DESC',
      [idParam(req.params.id)],
    );
    res.json({ manutencoes: rows });
  }),
);

// ---------- Corridas ----------

router.get(
  '/corridas',
  asyncH(async (req, res) => {
    const estado = req.query.estado
      ? enumerado(req.query.estado, 'estado', ['pedida', 'aceite', 'a_caminho', 'em_curso', 'concluida', 'cancelada'])
      : null;
    const limite = inteiro(req.query.limite ?? 50, 'limite', { min: 1, max: 200 });
    const antes = req.query.antes_id ? idParam(req.query.antes_id, 'antes_id') : null;
    const { rows } = await pool.query(
      `SELECT c.id, c.estado, c.tipo_veiculo, c.origem_descricao, c.destino_descricao, c.distancia_km,
              c.preco_estimado, c.preco_final, c.pedida_em, c.concluida_em, c.motivo_cancelamento,
              cu.nome AS cliente, mu.nome AS motorista, v.matricula
         FROM corridas c
         JOIN utilizadores cu ON cu.id = c.cliente_id
         LEFT JOIN utilizadores mu ON mu.id = c.motorista_id
         LEFT JOIN veiculos v ON v.id = c.veiculo_id
        WHERE ($1::text IS NULL OR c.estado::text = $1)
          AND ($2::bigint IS NULL OR c.id < $2::bigint)
        ORDER BY c.id DESC LIMIT $3`,
      [estado, antes, limite],
    );
    res.json({ corridas: rows });
  }),
);

// Disputa de preço: a administração corrige o valor final (a comissão é recalculada).
router.post(
  '/corridas/:id/ajustar-preco',
  asyncH(async (req, res) => {
    const id = idParam(req.params.id);
    const preco = numero(req.body?.preco_final, 'preco_final', { min: 0.01 });
    const motivo = texto(req.body?.motivo, 'motivo', { min: 3, max: 200 });

    const resultado = await tx(async (db) => {
      const { rows } = await db.query('SELECT estado, preco_final, motorista_id FROM corridas WHERE id = $1 FOR UPDATE', [id]);
      if (!rows.length) throw new ErroHttp(404, 'Corrida não encontrada');
      const c = rows[0];
      if (c.estado !== 'concluida') throw new ErroHttp(409, 'Só é possível ajustar corridas concluídas');

      const { rows: co } = await db.query('SELECT id, valor, percentagem, paga FROM comissoes WHERE corrida_id = $1 FOR UPDATE', [id]);
      const antiga = co[0];
      const nova = antiga ? Math.round(((preco * antiga.percentagem) / 100) * 100) / 100 : 0;
      const diferenca = antiga ? Math.round((nova - antiga.valor) * 100) / 100 : 0;

      await db.query('UPDATE corridas SET preco_final = $2 WHERE id = $1', [id, preco]);
      await db.query('UPDATE pagamentos SET valor = $2 WHERE corrida_id = $1', [id, preco]);
      if (antiga) {
        await db.query('UPDATE comissoes SET valor = $2 WHERE id = $1', [antiga.id, nova]);
        // Se a comissão ainda está por pagar, o saldo do motorista acompanha a correção.
        if (!antiga.paga) {
          await db.query('UPDATE motoristas SET saldo_comissoes = GREATEST(saldo_comissoes + $2, 0) WHERE utilizador_id = $1', [c.motorista_id, diferenca]);
        }
      }
      await db.query(
        'INSERT INTO ajustes_preco (corrida_id, admin_id, preco_antigo, preco_novo, motivo) VALUES ($1, $2, $3, $4, $5)',
        [id, req.utilizador.id, c.preco_final, preco, motivo],
      );
      return { preco_antigo: c.preco_final, preco_novo: preco, comissao_nova: nova, motivo };
    });
    res.json({ ok: true, ...resultado });
  }),
);

// ---------- Tarifas e zonas ----------

router.get(
  '/tarifas',
  asyncH(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM tarifas ORDER BY tipo_veiculo, id');
    res.json({ tarifas: rows });
  }),
);

function lerTarifa(b) {
  const geral = b.zona_origem_id == null && b.zona_destino_id == null;
  const t = {
    tipo_veiculo: enumerado(b.tipo_veiculo, 'tipo_veiculo', TIPOS_VEICULO),
    zona_origem_id: b.zona_origem_id == null ? null : idParam(b.zona_origem_id, 'zona_origem_id'),
    zona_destino_id: b.zona_destino_id == null ? null : idParam(b.zona_destino_id, 'zona_destino_id'),
    preco_fixo: numero(b.preco_fixo, 'preco_fixo', { min: 0.01, opcional: true }),
    taxa_base: numero(b.taxa_base ?? 0, 'taxa_base', { min: 0 }),
    preco_por_km: numero(b.preco_por_km, 'preco_por_km', { min: 0.01, opcional: true }),
  };
  if ((t.zona_origem_id == null) !== (t.zona_destino_id == null)) {
    throw new ErroHttp(400, 'Indique as duas zonas (origem e destino) ou nenhuma');
  }
  if (geral && t.preco_por_km === null) throw new ErroHttp(400, 'A tarifa geral precisa de "preco_por_km"');
  if (!geral && t.preco_fixo === null) throw new ErroHttp(400, 'A tarifa entre zonas precisa de "preco_fixo"');
  return t;
}

router.post(
  '/tarifas',
  asyncH(async (req, res) => {
    const t = lerTarifa(req.body ?? {});
    const { rows } = await tx(async (db) => {
      // Mantém no máximo uma tarifa ativa por combinação (tipo + zonas).
      await db.query(
        `UPDATE tarifas SET ativo = FALSE
          WHERE tipo_veiculo = $1 AND ativo
            AND zona_origem_id IS NOT DISTINCT FROM $2 AND zona_destino_id IS NOT DISTINCT FROM $3`,
        [t.tipo_veiculo, t.zona_origem_id, t.zona_destino_id],
      );
      return db.query(
        `INSERT INTO tarifas (tipo_veiculo, zona_origem_id, zona_destino_id, preco_fixo, taxa_base, preco_por_km)
         VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
        [t.tipo_veiculo, t.zona_origem_id, t.zona_destino_id, t.preco_fixo, t.taxa_base, t.preco_por_km],
      );
    });
    res.status(201).json({ tarifa: rows[0] });
  }),
);

router.delete(
  '/tarifas/:id',
  asyncH(async (req, res) => {
    const { rowCount } = await pool.query('UPDATE tarifas SET ativo = FALSE WHERE id = $1', [idParam(req.params.id)]);
    if (!rowCount) throw new ErroHttp(404, 'Tarifa não encontrada');
    res.json({ ok: true });
  }),
);

router.post(
  '/zonas',
  asyncH(async (req, res) => {
    const { rows } = await pool.query('INSERT INTO zonas (nome, cidade) VALUES ($1, $2) RETURNING *', [
      texto(req.body?.nome, 'nome', { max: 100 }),
      texto(req.body?.cidade, 'cidade', { max: 100 }),
    ]);
    res.status(201).json({ zona: rows[0] });
  }),
);

router.post(
  '/pontos',
  asyncH(async (req, res) => {
    const b = req.body ?? {};
    const { lat, lng } = coordenadas(b.latitude, b.longitude);
    const zona = b.zona_id == null ? null : idParam(b.zona_id, 'zona_id');
    if (zona) {
      const { rowCount } = await pool.query('SELECT 1 FROM zonas WHERE id = $1', [zona]);
      if (!rowCount) throw new ErroHttp(404, 'Zona não encontrada');
    }
    const { rows } = await pool.query(
      `INSERT INTO pontos_referencia (nome, categoria, latitude, longitude, zona_id)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [texto(b.nome, 'nome', { max: 120 }), texto(b.categoria, 'categoria', { max: 40, opcional: true }), lat, lng, zona],
    );
    res.status(201).json({ ponto: rows[0] });
  }),
);

router.delete(
  '/pontos/:id',
  asyncH(async (req, res) => {
    try {
      const { rowCount } = await pool.query('DELETE FROM pontos_referencia WHERE id = $1', [idParam(req.params.id)]);
      if (!rowCount) throw new ErroHttp(404, 'Ponto não encontrado');
    } catch (e) {
      if (e.code === '23503') throw new ErroHttp(409, 'Este ponto já foi usado em corridas e não pode ser apagado');
      throw e;
    }
    res.json({ ok: true });
  }),
);

// ---------- Finanças ----------

router.get(
  '/comissoes',
  asyncH(async (req, res) => {
    const { rows } = await pool.query(
      `SELECT m.utilizador_id AS motorista_id, u.nome, u.telefone, m.saldo_comissoes,
              COUNT(co.id) FILTER (WHERE NOT co.paga) AS corridas_por_pagar
         FROM motoristas m
         JOIN utilizadores u ON u.id = m.utilizador_id
         LEFT JOIN comissoes co ON co.motorista_id = m.utilizador_id
        GROUP BY m.utilizador_id, u.nome, u.telefone, m.saldo_comissoes
       HAVING m.saldo_comissoes > 0
        ORDER BY m.saldo_comissoes DESC`,
    );
    res.json({ devedores: rows, limite_divida: config.limiteDivida });
  }),
);

// Registo de um pagamento de comissões (dinheiro entregue ou M-Pesa recebido). Salda as mais antigas primeiro.
router.post(
  '/comissoes/pagamento',
  asyncH(async (req, res) => {
    const motoristaId = idParam(req.body?.motorista_id, 'motorista_id');
    const valor = numero(req.body?.valor, 'valor', { min: 0.01 });
    const referencia = texto(req.body?.referencia, 'referencia', { max: 80, opcional: true });

    const resultado = await tx(async (db) => {
      const { rows: m } = await db.query('SELECT saldo_comissoes FROM motoristas WHERE utilizador_id = $1 FOR UPDATE', [motoristaId]);
      if (!m.length) throw new ErroHttp(404, 'Motorista não encontrado');
      if (valor > m[0].saldo_comissoes + 0.001) {
        throw new ErroHttp(422, `O valor excede o saldo em dívida (${m[0].saldo_comissoes} MT)`);
      }
      const { rows: pendentes } = await db.query(
        'SELECT id, valor FROM comissoes WHERE motorista_id = $1 AND NOT paga ORDER BY id FOR UPDATE',
        [motoristaId],
      );
      let restante = valor;
      const saldadas = [];
      for (const c of pendentes) {
        if (restante + 0.001 < c.valor) break; // só salda comissões inteiras; o resto fica como crédito no saldo
        restante = Math.round((restante - c.valor) * 100) / 100;
        saldadas.push(c.id);
      }
      if (saldadas.length) {
        await db.query('UPDATE comissoes SET paga = TRUE, paga_em = NOW() WHERE id = ANY($1::bigint[])', [saldadas]);
      }
      const { rows: novo } = await db.query(
        'UPDATE motoristas SET saldo_comissoes = GREATEST(saldo_comissoes - $2, 0) WHERE utilizador_id = $1 RETURNING saldo_comissoes',
        [motoristaId, valor],
      );
      return { saldo_comissoes: novo[0].saldo_comissoes, comissoes_saldadas: saldadas.length, referencia };
    });
    res.json({ ok: true, ...resultado });
  }),
);

router.get(
  '/relatorio',
  asyncH(async (req, res) => {
    const de = dataISO(req.query.de, 'de');
    const ate = dataISO(req.query.ate, 'ate');
    if (de > ate) throw new ErroHttp(400, '"de" não pode ser depois de "ate"');
    const formato = enumerado(req.query.formato ?? 'json', 'formato', ['json', 'csv']);

    const { rows } = await pool.query(
      `SELECT (c.concluida_em AT TIME ZONE 'UTC' AT TIME ZONE $3)::date AS dia,
              COUNT(*) AS corridas,
              COALESCE(SUM(c.preco_final), 0) AS movimento,
              COALESCE(SUM(co.valor), 0) AS comissoes
         FROM corridas c
         LEFT JOIN comissoes co ON co.corrida_id = c.id
        WHERE c.estado = 'concluida'
          AND (c.concluida_em AT TIME ZONE 'UTC' AT TIME ZONE $3)::date BETWEEN $1::date AND $2::date
        GROUP BY 1 ORDER BY 1`,
      [de, ate, config.fuso],
    );
    const dias = rows.map((r) => ({ ...r, dia: typeof r.dia === 'string' ? r.dia : r.dia.toISOString().slice(0, 10) }));

    if (formato === 'csv') {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="relatorio-${de}-a-${ate}.csv"`);
      return res.send(
        csv(
          [
            { titulo: 'Dia', chave: 'dia' },
            { titulo: 'Corridas', chave: 'corridas' },
            { titulo: 'Movimento (MT)', chave: 'movimento' },
            { titulo: 'Comissões (MT)', chave: 'comissoes' },
          ],
          dias,
        ),
      );
    }
    return res.json({
      de,
      ate,
      dias,
      total: {
        corridas: dias.reduce((s, d) => s + d.corridas, 0),
        movimento: Math.round(dias.reduce((s, d) => s + d.movimento, 0) * 100) / 100,
        comissoes: Math.round(dias.reduce((s, d) => s + d.comissoes, 0) * 100) / 100,
      },
    });
  }),
);

// ---------- Reclamações e emergências ----------

router.get(
  '/reclamacoes',
  asyncH(async (req, res) => {
    const estado = req.query.estado ? enumerado(req.query.estado, 'estado', ['aberta', 'em_analise', 'resolvida', 'rejeitada']) : null;
    const { rows } = await pool.query(
      `SELECT r.*, u.nome AS autor, u.telefone AS autor_telefone
         FROM reclamacoes r JOIN utilizadores u ON u.id = r.autor_id
        WHERE ($1::text IS NULL OR r.estado::text = $1)
        ORDER BY r.id DESC LIMIT 100`,
      [estado],
    );
    res.json({ reclamacoes: rows });
  }),
);

router.patch(
  '/reclamacoes/:id',
  asyncH(async (req, res) => {
    const estado = enumerado(req.body?.estado, 'estado', ['em_analise', 'resolvida', 'rejeitada']);
    const resolucao = texto(req.body?.resolucao, 'resolucao', { max: 2000, opcional: estado === 'em_analise' });
    const { rows } = await pool.query(
      `UPDATE reclamacoes
          SET estado = $2, resolucao = COALESCE($3, resolucao),
              resolvida_em = CASE WHEN $2 IN ('resolvida', 'rejeitada') THEN NOW() ELSE NULL END
        WHERE id = $1 RETURNING *`,
      [idParam(req.params.id), estado, resolucao],
    );
    if (!rows.length) throw new ErroHttp(404, 'Reclamação não encontrada');
    res.json({ reclamacao: rows[0] });
  }),
);

router.get(
  '/emergencias',
  asyncH(async (req, res) => {
    const { rows } = await pool.query(
      `SELECT a.*, u.nome, u.telefone, u.contacto_emergencia
         FROM alertas_emergencia a JOIN utilizadores u ON u.id = a.utilizador_id
        ORDER BY a.resolvido, a.id DESC LIMIT 100`,
    );
    res.json({ alertas: rows });
  }),
);

router.post(
  '/emergencias/:id/resolver',
  asyncH(async (req, res) => {
    const { rowCount } = await pool.query('UPDATE alertas_emergencia SET resolvido = TRUE WHERE id = $1', [idParam(req.params.id)]);
    if (!rowCount) throw new ErroHttp(404, 'Alerta não encontrado');
    res.json({ ok: true });
  }),
);

export default router;
