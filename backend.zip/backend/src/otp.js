import { createHmac, timingSafeEqual } from 'node:crypto';
import { config } from './config.js';

export function hashCodigo(telefone, codigo) {
  return createHmac('sha256', config.jwtSegredo).update(`${telefone}:${codigo}`).digest('hex');
}

export function iguais(hashA, hashB) {
  const a = Buffer.from(hashA, 'hex');
  const b = Buffer.from(hashB, 'hex');
  return a.length === b.length && timingSafeEqual(a, b);
}
