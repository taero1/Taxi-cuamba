const RAIO_TERRA_KM = 6371;
const rad = (g) => (g * Math.PI) / 180;

// Distância em linha reta entre dois pontos (km).
export function haversineKm(lat1, lng1, lat2, lng2) {
  const dLat = rad(lat2 - lat1);
  const dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * RAIO_TERRA_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

// O mesmo cálculo em SQL (km). Recebe nomes de colunas e referências a parâmetros ($1, $2...) escritos no código.
export function sqlDistKm(latCol, lngCol, latParam, lngParam) {
  return `(2 * ${RAIO_TERRA_KM} * asin(LEAST(1, sqrt(
    power(sin(radians((${latParam}::float8 - ${latCol}::float8) / 2)), 2) +
    cos(radians(${latCol}::float8)) * cos(radians(${latParam}::float8)) *
    power(sin(radians((${lngParam}::float8 - ${lngCol}::float8) / 2)), 2)
  ))))`;
}
