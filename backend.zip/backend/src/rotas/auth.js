import { Router } from 'express';
import { randomInt } from 'node:crypto';
import { pool, query, tx } from '../db.js';
import { ErroHttp, asyncH } from '../erros.js';
import { autenticar, gerarToken } from '../auth.js';
import { hashCodigo, iguais } from '../otp.js';
import { enviarSms } from '../sms.js';
import { enumerado, normalizarTelefone, texto } from '../validar.js';

const router = Router();

// 1) O utilizador indica o telefone e recebe um código por SMS.
router.post(
  '/pedir-codigo',
  asyncH(async (req, res) => {
    const telefone = normalizarTelefone(req.body?.telefone);

    const { rows } = await query(
      `SELECT COUNT(*) AS n FROM otp_codigos WHERE telefone = $1 AND criado_em > NOW() - INTERVAL '1 hour'`,
      [telefone],
    );
    if (rows[0].n >= 5) throw new ErroHttp(429, 'Demasiados pedidos de código. Tente novamente mais tarde.');

    const codigo = String(randomInt(0, 1_000_000)).padStart(6, '0');
    await query(
      `INSERT INTO otp_codigos (telefone, codigo_hash, expira_em) VALUES ($1, $2, NOW() + INTERVAL '10 minutes')`,
      [telefone, hashCodigo(telefone, codigo)],
    );
    await enviarSms(telefone, `O seu código de acesso é ${codigo}. Válido por 10 minutos.`);
    res.json({ ok: true, mensagem: 'Código enviado por SMS' });
  }),
);

// 2) Confirma o código. No primeiro acesso é preciso enviar também "nome" (e opcionalmente "tipo").
router.post(
  '/verificar-codigo',
  asyncH(async (req, res) => {
    const telefone = normalizarTelefone(req.body?.telefone);
    const codigo = String(req.body?.codigo ?? '').trim();
    if (!/^\d{6}$/.test(codigo)) throw new ErroHttp(400, 'O código deve ter 6 dígitos');

    const resultado = await tx(async (db) => {
      const { rows } = await db.query(
        `SELECT id, codigo_hash, tentativas FROM otp_codigos
          WHERE telefone = $1 AND NOT usado AND expira_em > NOW()
          ORDER BY id DESC LIMIT 1
          FOR UPDATE`,
        [telefone],
      );
      const otp = rows[0];
      if (!otp) return { erro: [400, 'Código expirado ou inexistente. Peça um novo.'] };
      if (otp.tentativas >= 5) return { erro: [429, 'Demasiadas tentativas. Peça um novo código.'] };

      if (!iguais(otp.codigo_hash, hashCodigo(telefone, codigo))) {
        await db.query('UPDATE otp_codigos SET tentativas = tentativas + 1 WHERE id = $1', [otp.id]);
        return { erro: [400, 'Código incorreto'] };
      }
      await db.query('UPDATE otp_codigos SET usado = TRUE WHERE id = $1', [otp.id]);

      let { rows: [utilizador] } = await db.query(
        'SELECT id, nome, telefone, tipo, estado FROM utilizadores WHERE telefone = $1',
        [telefone],
      );
      let novo = false;
      if (!utilizador) {
        // Se faltar o nome, a transação é desfeita e o código continua válido.
        if (!req.body?.nome) throw new ErroHttp(400, 'Primeiro acesso: indique o seu nome', { precisa_registo: true });
        const nome = texto(req.body.nome, 'nome', { min: 2, max: 120 });
        const tipo = enumerado(req.body.tipo ?? 'cliente', 'tipo', ['cliente', 'motorista']);
        ({ rows: [utilizador] } = await db.query(
          `INSERT INTO utilizadores (nome, telefone, tipo) VALUES ($1, $2, $3)
           RETURNING id, nome, telefone, tipo, estado`,
          [nome, telefone, tipo],
        ));
        novo = true;
      }
      return { utilizador, novo };
    });

    if (resultado.erro) throw new ErroHttp(...resultado.erro);
    const { utilizador, novo } = resultado;
    if (utilizador.estado !== 'ativo') throw new ErroHttp(403, 'Conta suspensa ou bloqueada. Contacte o apoio.');

    res.status(novo ? 201 : 200).json({
      token: gerarToken(utilizador),
      novo_utilizador: novo,
      utilizador: { id: utilizador.id, nome: utilizador.nome, telefone: utilizador.telefone, tipo: utilizador.tipo },
    });
  }),
);

router.get(
  '/eu',
  autenticar,
  asyncH(async (req, res) => {
    const u = req.utilizador;
    const { rows } = await pool.query('SELECT contacto_emergencia FROM utilizadores WHERE id = $1', [u.id]);
    let motorista = null;
    if (u.tipo === 'motorista') {
      const r = await pool.query(
        `SELECT verificacao, avaliacao_media, total_corridas, online, saldo_comissoes
           FROM motoristas WHERE utilizador_id = $1`,
        [u.id],
      );
      motorista = r.rows[0] ?? null;
    }
    res.json({
      utilizador: { id: u.id, nome: u.nome, telefone: u.telefone, tipo: u.tipo, contacto_emergencia: rows[0].contacto_emergencia },
      motorista,
    });
  }),
);

router.patch(
  '/eu',
  autenticar,
  asyncH(async (req, res) => {
    const b = req.body ?? {};
    const nome = b.nome === undefined ? undefined : texto(b.nome, 'nome', { min: 2, max: 120 });
    const contacto =
      b.contacto_emergencia === undefined
        ? undefined
        : b.contacto_emergencia === null || b.contacto_emergencia === ''
          ? null
          : normalizarTelefone(b.contacto_emergencia);
    if (nome === undefined && contacto === undefined) throw new ErroHttp(400, 'Nada para atualizar');

    const { rows } = await pool.query(
      `UPDATE utilizadores
          SET nome = COALESCE($2, nome),
              contacto_emergencia = CASE WHEN $3::boolean THEN $4 ELSE contacto_emergencia END
        WHERE id = $1
        RETURNING id, nome, telefone, tipo, contacto_emergencia`,
      [req.utilizador.id, nome ?? null, contacto !== undefined, contacto ?? null],
    );
    res.json({ utilizador: rows[0] });
  }),
);

export default router;
